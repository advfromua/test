//Drilled Dashboard Selection Menu Class
function DrilledDashboardSelectionMenu(widget) {
    //check if event already registered
    if (isRegistered()) {
        return;
    }

    DrilledDashboardSelection.call(this, widget);

    //remove events
    function removeOnBeforeMenu(widget, args) {
        var eventdef = $$get(prism.$ngscope.$$listeners["beforemenu"]);
        var index = eventdef.indexOf(setDashboardsMenu);

        eventdef.splice(index, 1);
        widget.off("destroyed", removeOnBeforeMenu);
    }

    //set events
    prism.on("beforemenu", setDashboardsMenu);
    widget.on("destroyed", removeOnBeforeMenu);
}
//set dashboards menu
function setDashboardsMenu(e, args) {
    var target = $(args.ui.target);

    // Check if user in view mode.
    var isUserNotAllowToChangeJTD = $$get(prism, 'activeDashboard.userAuth.base.isConsumer')
        || !$$get(prism, 'activeDashboard.userAuth.widgets.edit');

    if (isUserNotAllowToChangeJTD) {
        return;
    }

    // Allow JTD option for widget menu at edit mode ('js--btn-widget-menu' for v7.0; 'wet-menu' for v6.7) and dashboard mode ('widget-header--title-edited')
    var isMenuAllowedForJTD = target.hasClass('js--btn-widget-menu') || target.hasClass('wet-menu') || target.hasClass('widget-header--title-edited');

    if ((!isMenuAllowedForJTD && !target.find('.menu-btn').length) || target.is('widget')) {
        return;
    }

    //saves widget configurations
    var appstate = e.currentScope.appstate;
    var widget = appstate === 'widget' ? e.currentScope.widget : args.settings.scope.widget;

    if (!widget ||
        /*adds menu on dashboard to widget only for richtexteditor*/
        (widget.type !== 'richtexteditor' && appstate === 'dashboard') ||
        /*if a drilled dashboard defined as a widget configuration, don't set the menu:*/
        (defined(widget, 'drillToDashboardConfig.dashboardId'))
    ) {
        return;
    }

    //get drilled dashboards with the same data source
    var displayAndGetDashboardsFunctions =
        prism.$injector.get('plugin-jumpToDashboard.services.displayAndGetDashboardsFunctions');
    var drilledDashboards =
        displayAndGetDashboardsFunctions.getTargetDashboardList(widget);

    //get drill menu item
    var drillMenuItem = _.find(args.settings.items, function (item) {
        return item.caption === widget.drillToDashboardConfig.drillToDashboardMenuCaption
    });
    var widgetElement = getWidgetElement(widget);
    var isLeft;
    var isTextWidget = widget.type === 'richtexteditor';

    if (drilledDashboards.items.length) {
        if (widgetElement.length > 0) {
            isLeft = widgetElement.offset().left + widgetElement.width() - 235 > drilledDashboards.design.sizeForReachTextBox;
        }

        //update dashboards list
        if (drillMenuItem) {
            drillMenuItem.items = drilledDashboards.items || drilledDashboards;
        }
        //add drill menu item
        else {
            args.settings.isLeftSlideMenu = drilledDashboards.design.drillLeft;
            args.settings.items.push({type: "separator"});
            args.settings.items.push({
                caption: widget.drillToDashboardConfig.drillToDashboardMenuCaption,
                drillLeft: isTextWidget ? (drilledDashboards.design.drillLeft && isLeft) :
                drilledDashboards.design.drillLeft,
                items: drilledDashboards.items,
                classes: drilledDashboards.design.menuClass,
                margin: drilledDashboards.design.drillLeft ? -235 : 0
                });
        }
    }
}
//check if event already registered
function isRegistered() {
    if (defined(prism.$ngscope.$$listeners.beforemenu)) {
        var handlerArr = prism.$ngscope.$$listeners.beforemenu.filter(function(fn) {
            return fn === setDashboardsMenu;
        });
        if (handlerArr.length ) {
            return true;
        }
    }
    return false;
}
DrilledDashboardSelectionMenu.prototype = Object.create(DrilledDashboardSelection.prototype);
DrilledDashboardSelectionMenu.prototype.constructor = DrilledDashboardSelectionMenu;
