var allowedTypes = ["pivot", "pivot2", "chart/pie", "chart/line", "chart/area", "chart/bar", "chart/column", "indicator",
    "chart/scatter", "imageWidget", "richtexteditor", "trelliswidget", "chart/polar", "BloX"];
var otherTypes = ["indicator", "imageWidget", "richtexteditor"];
var proxyUrl = prism.proxyurl ? prism.proxyurl : "";
var baseUrl = proxyUrl || (window.sisenseMobileApp ? prism.origin : '');

//variable for custom config
prism.JTDConfigs = [];

//  this is consumed by the mobile app only, for hiding dashboards with jtd prefix
if (window.sisenseMobileApp) {
    prism.JTDConfigs['prefix'] = appConfig.drilledDashboardPrefix;
}

//load widget configuration
prism.jumpToDashboard = function (widget, args) {

    if (args === undefined) {
        return;
    }

    var config = angular.extend(_.clone(appConfig), args);

    //save custom configuration from Edit Script
    prism.JTDConfigs[widget.oid] = config;

    widget.drillToDashboardConfig = config;
    widget.drillToDashboardConfig.custom = true;
};

prism.run([
    '$dashboard',
    'widget-editor.services.$popper',
    'plugin-jumpToDashboard.services.dashboardHideService',
    'plugin-jumpToDashboard.services.dashboardUpdateAttributesService',
    'plugin-jumpToDashboard.services.displayAndGetDashboardsFunctions',
    'plugin-jumpToDashboard.services.jtdForMobileService',
    'plugin-jumpToDashboard.services.filtersHelperService',
    function ($dashboard, $popper, $dashboardHideService, $dashboardUpdateAttributesService, $displayAndGetDashboardsFunctions, $jtdForMobileService, $filtersHelperService) {

        // break if it's embedded by SisenseJS
        if (prism.isStandalone) {
            return;
        }

        if (window.sisenseMobileApp) {
            $jtdForMobileService.init();
            return;
        }

        $dashboardHideService.init();

        function deleteMenuItemsIfNeeded(settings) {
            var widget = $$get(settings, 'widget', {});
            var items = $$get(settings, 'items', []);
            var isJumpable = $displayAndGetDashboardsFunctions.checkIfJumpable(widget);
            var isDrillToAnywhere = $$get(widget, 'options.drillToAnywhere', true);
            var isSelectable = $$get(widget, 'options.selector', true);
            var isDatapointMenu = $$get(settings, 'name', '') === 'datapoint';

            if (isDatapointMenu && !isDrillToAnywhere && !isSelectable && items.length <= 2 && !isJumpable) {
                items.length = 0;
            }
        }

        prism.on('beforemenu', function(ev, args) {
            var settings = args.settings;
            removeTempItem($$get(settings, 'items', []));
            deleteMenuItemsIfNeeded(settings);

            $dashboardHideService.beforeMenuHandler(ev, args);
        });

        //adds support for Function.name ( IE issue )
        if (Function.prototype.name === undefined && Object.defineProperty !== undefined) {
            Object.defineProperty(Function.prototype, 'name', {
                get: function () {
                    var funcNameRegex = /function\s([^(]{1,})\(/;
                    var results = (funcNameRegex).exec((this).toString());
                    return (results && results.length > 1) ? results[1].trim() : "";
                },
                set: function (value) {
                }
            });
        }
        prism.on("filtersready", function(e, args) {
            var isPreviewOrPhantom = $('.db-preview-modal').length > 0 || window.navigator.userAgent.includes('phantom');
            if (!isPreviewOrPhantom && appConfig.resetDashFiltersAfterJTD && shouldUpdateFilters(prism.activeDashboard)) {
                updateFilters(prism.activeDashboard);
            }
        })
        // Registering widget events
        prism.on("dashboardloaded", function (e, args) {
            args.dashboard.widgets.toArray().forEach(function(widget) {
                $displayAndGetDashboardsFunctions.applyJTDForPivot2(widget);
            });

            args.dashboard.on("widgetinitialized", function (dash, args) {
                if (!hasEventHandler(args.widget, "render", onWidgetRender)) {
                    args.widget.on('render', onWidgetRender);
                }

                if (!hasEventHandler(args.widget, "beforeviewloaded", onWidgetRender)) {
                    args.widget.on('beforeviewloaded', onBeforeviewloaded);
                }
            });

            args.dashboard.on('filterschanged', function(dash) {
                if (defined(dash.openFromJTD)) {
                    dash.openFromJTD = false;
                    $dashboardUpdateAttributesService.updateAttributes(dash, ['filtersToRestore', 'openFromJTD']);
                }
            });
        });

        var originalPopMenuCustom = $popper.popMenuCustom;

        // Override (wrap) popMenuCustom function
        $popper.popMenuCustom = function (items, ev, ok, ui, settings) {

            // Adds temporal fake item to menu drill to force its display
            if (settings && settings.directive === '<data-menu-drill></data-menu-drill>') {
                items.push({
                    caption: 'Temporary_item',
                    mid: 'none'
                });
            }
            originalPopMenuCustom(items, ev, ok, ui, settings);
        };

        // Removes temporary item from popup
        function removeTempItem(items) {
            var tempItem = items.find( function(item) { return item.caption === 'Temporary_item'; } );

            if (tempItem) {
                items.splice(items.indexOf(tempItem), 1);
            }
        }

        function shouldUpdateFilters(dashboard) {
            if (!defined(dashboard.openFromJTD)) {
                return false;
            }

            if (dashboard.openFromJTD) {
                dashboard.openFromJTD = false;
                dashboard.$dashboard.updateDashboard(dashboard, "openFromJTD");
                return dashboard.openFromJTD;
            }

            return true;
        }

        function updateFilters(dashboard) {
            var filtersToRestore = $$get(dashboard, "filtersToRestore");

            // Restore the original filters
            if (filtersToRestore.length) {
                deleteDashboardAttributes(dashboard, ["filtersToRestore", "openFromJTD"]);

                var options = {
                    refresh: false,
                    save: true, //set false due to ISSUE in dashboard-updated event
                    unionIfSameDimensionAndSameType: true,
                    shouldResetNonSelectedDimensionsFilters: true,
                    reason: 'filtersUpdated'
                };

                dashboard.filters.clear();

                // update dashboard filters according to selected drill item
                dashboard.filters.update(filtersToRestore, options);
            } else {
                deleteDashboardAttributes(dashboard, ["filtersToRestore", "openFromJTD"]);
                dashboard.filters.clear();
                dashboard.$dashboard.updateDashboard(dashboard, "filters");
            }
        }

        function deleteDashboardAttributes(dashboard, attributes) {
            attributes.forEach(function (att) {
                dashboard[att] = null;
            });

            // Update attributes directly. Was needed to send attributes with null value to mongoDB
            $dashboardUpdateAttributesService.updateAttributes(dashboard, attributes);
        }


        //add drilling image indicator
        function setDrillingImage(widget, args) {
            var widgetElement = getWidgetElement(widget),
                drillImageElement = widgetElement.find('.jtd-title-img');

            if (!drillImageElement.length && args.widget.drillToDashboardConfig.showJTDIcon) {
                widgetElement.find('widget-header').prepend("<div class='jtd-title-img' title='This widget is jumpable' />");
            }

            //target dashboard is set through widget menu or target dashboard ids is set through widget script
            if (args.widget.options.drillTarget || args.widget.drillToDashboardConfig.dashboardIds.length) {
                widgetElement.addClass('jumpable');

            } else {
                widgetElement.removeClass('jumpable');
            }
        }

        function onBeforeviewloaded(widget, args) {
            var isPieChartWithNoCategories = $filtersHelperService.isPieChartWithoutCategories(widget);

            var config = setWidgetConfig(widget);

            // Check if widget type is supported and widget has JTD enabled
            if (!defined(widget.options.drillTarget)
                && widget.drillToDashboardConfig.dashboardIds.length === 0) {
                    return;
            }

            // Apply right click on line chart
            if ($$get(config, "drillToDashboardNavigateType") === 3 &&
                widget.type === "chart/line") {
                args.options.plotOptions.series.point.events.click = function (target) {
                    // Pass the target to the getFilters function if you wish to pass the widget filters
                    // to the JTD
                    var xAxisItems = widget.metadata.items(function(item) {
                        return item.$$panel.name === "x-axis" && !item.disabled;
                    });

                    var filters = $filtersHelperService.getFilters(widget, target) || [];
                    var selectionData = target.point.selectionData;

                    if ($$get(xAxisItems, "length") > 0 && selectionData) {
                        _.each(xAxisItems, function (item, index) {
                            var existingFilter = _.find(filters, function (existsFilter) {
                                return existsFilter.jaql.dim === item.jaql.dim;
                            });

                            var newFilter = existingFilter || { jaql: item.jaql };

                            if (!existingFilter) {
                                filters.push(newFilter);
                            }

                            newFilter.jaql.filter = {
                                explicit: true,
                                members: [selectionData[index]],
                                multiSelection: true
                            };
                        });
                    }

                    widget.drilledDashboardDisplay.display(filters,
                        widget.drillToDashboardConfig,
                        widget.options.drillTarget);
                };
            }

            // Apply click on pie chart
            if (isPieChartWithNoCategories) {
                args.options.plotOptions.pie.point.events.click = function (target) {
                    // Pass the target to the getFilters function if you wish to pass the widget
                    // filters to the JTD
                    var targetToSend = config.sendPieChartMeasureFiltersOnClick ? target : undefined;
                    var filters = $filtersHelperService.getFilters(widget, targetToSend);
                    widget.drilledDashboardDisplay.display(filters,
                        widget.drillToDashboardConfig,
                        widget.options.drillTarget);
                };
            }
        }

        function getWidgetConfig(widget) {
            return $displayAndGetDashboardsFunctions.getWidgetJTDConfig(widget, appConfig);
        }

        function setWidgetConfig(widget) {
            var config = getWidgetConfig(widget);
            widget.drillToDashboardConfig = config;

            return config;
        }

        function onWidgetRender(widget, args) {
            // Check if widget type is supported
            if (allowedTypes.indexOf(args.widget.type) === -1) {
                return;
            }

            var config = setWidgetConfig(args.widget);

            if (!config.dashboardId) {
                new DrilledDashboardSelectionMenu(args.widget);
            } else {
                delete args.widget.options.drillTarget;
                new DrilledDashboardSelectionId(args.widget);
            }

            setDrillingImage(widget, args);

            if (!args.widget.options.drillTarget && !config.dashboardIds.length) {
                return;
            }

            // set custom navigation type for BloX widgets
            if ( args.widget.type == 'BloX') {
                args.widget.drillToDashboardConfig.drillToDashboardNavigateType = 4;
            }

            switch (config.drillToDashboardNavigateType) {
                case 2:
                    new DrillToDashboardNavigateTypeLink(args.widget);
                    break;
                case 3:
                    new DrillToDashboardNavigateTypeClick(args.widget);
                    break;
                case 4:
                    new DrillToDashboardNavigateTypeBloXAction(args.widget);
                    break;
                default:
                    new DrillToDashboardNavigateTypeRightClick(args.widget).initialize();
            }
        }
    }
]);

// utility function to check if model contains certain event handler for specified event name
var hasEventHandler = function (model, eventName, handler) {
    return model.$$eventHandlers(eventName).indexOf(handler) >= 0;
};

var popNotFoundModal = function () {
    var $dom = prism.$injector.get("ux-controls.services.$dom");

    $dom.modal({
        scope: "fake",
        template: "<jtd-error-msg></jtd-error-msg>",
        css: "err-modal"
    });
};


function getWidgetElement(widget) {
    var widgetElement;
    switch (prism.$ngscope.appstate) {
        case "widget":
            widgetElement = $(".widget-body").not(".prism-persistent-mainview-holder .widget-body");
            break;
        case "dashboard":
            widgetElement = $('widget[widgetid="' + widget.oid + '"]').not("[widget-preview='true']");
            break;
        default:
            widgetElement = $('widget[widgetid="' + widget.oid + '"]').not("[widget-preview='true']");
    }
    return widgetElement
}
