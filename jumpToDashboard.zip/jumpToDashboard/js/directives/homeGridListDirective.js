// Modify 'homeTilesList' directive to hide shared dashboards by drilled prefix and by active 'hide for non-owners' configuration
// Hides dashboards for non-owners in the homepage tiles list section

if (window.home) {

    home.directive('forPluginsHomeTableList', [
        'plugin-jumpToDashboard.services.dashboardHideService',
        function (dashboardHideService) {
            return {
                restrict: 'C',
                link: function link($scope, lmnt, attrs) {

                    $scope.$watchCollection('items', function (items) {
                        if (!items) {
                            items = [];
                        }

                        if (appConfig.hideDrilledDashboards) {
                            // Hide dashboards for non owners + if dash has prefix + if dash in folder that has prefix
                            items = dashboardHideService.hideDrilledDashboards(items);
                            $scope.items = items;
                        }

                        if (appConfig.hideSharedDashboardsForNonOwner) {
                            dashboardHideService.getDashboardsHideModel()
                                .then(function (dashboards) {
                                    $scope.items = dashboardHideService.hideSharedDashboardsForNonOwner(dashboards, items);
                                });
                        }
                    });
                }
            }
        }
    ]);
}