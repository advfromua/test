// Directive of action button for 'hide for non-owners' functionality in 'multi select' dashboards navigator mode.

navver.directive('navverHideAction', [
    'plugin-jumpToDashboard.services.versionChecker',
    function ($versionChecker) {
        return {
            restrict: 'EAC',
            templateUrl: "/plugins/jumpToDashboard/templates/navverHideAction.html",
            link: function link($scope, lmnt, attrs) {

                $scope.isNewUI = $versionChecker.isVersionGreaterEqual("7");

            }
        }
    }
]);