if (typeof main !== 'undefined') {
    main.directive("menuContent", [function () {
        return {
            restrict: 'C',
            link: function ($scope, lmnt, attrs) {
                if ($('.drillable').length > 0 && !$(lmnt).hasClass('drillList')) {                   
                    $(lmnt).addClass('drillList');
                    // Hide to prevent flickering.
                    lmnt[0].style.opacity = 0; 

                    window.setTimeout(function () {
                        // DOM has finished rendering.
                        // Now we can detect the frill menu dimensions and move it if necessary.
                     
                        var container = $(lmnt).closest(".menu-item-host")[0];
                        lmnt[0].style.maxHeight = "80vh";

                        if (container.style.bottom) {                                                   
                            container.style.top = container.style.bottom;
                            container.style.bottom = "0px";                          
                        }
                        
                        if(container.style.right){
                            lmnt[0].style.width = "auto";
                            lmnt[0].style.minWidth = "unset";
                            lmnt[0].style.maxWidth = "none";
                        }
                      
                        // Show element back.
                        lmnt[0].style.opacity = 1; 
                    }, 0);
                }
            }
        }
    }]);
}