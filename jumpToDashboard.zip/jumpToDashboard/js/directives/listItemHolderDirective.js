// Modify 'listItemHolder' directive to hide shared dashboards and folders by drilled prefix and by active 'hide for non-owners' configuration.
// Hides dashboards for non-owners in dashboards navigator left panel.

navver.directive('listItemHolder', [
    'plugin-jumpToDashboard.services.dashboardHideService',
    function (dashboardHideService) {
        return {
            restrict: 'C',
            link: function link($scope, lmnt) {

                var listItem = $scope.listItem;

                function hideDrilledDashboards() {
                    appConfig.hideDrilledDashboards && dashboardHideService.hidePrefixedListItem(listItem, lmnt);
                }

                function checkIfDashIsHidden(dashboardsHideModel, oid, hideFlagAttr) {
                    var dashboardModel = _.find(dashboardsHideModel, _.matcher({oid: oid}));
                    return $$get(dashboardModel, hideFlagAttr, false);
                }

                function checkIfDashInFolderIsHidden(dashboardsHideModel) {
                    return dashboardHideService.getNavverItemDashboards(listItem)
                        .every(function(dashboard) {
                            var dashboardHideFlag =
                                checkIfDashIsHidden(dashboardsHideModel, dashboard.oid, dashboardHideService.hideFlagAttr);
                            var isDashboardShared = dashboard.owner !== prism.user._id;

                            return isDashboardShared && dashboardHideFlag;
                        });
                }

                function isListItemHidden(dashboardsHideModel) {
                    if (listItem.objType === 'dashboard') {
                        return checkIfDashIsHidden(dashboardsHideModel, listItem.oid, dashboardHideService.hideFlagAttr);
                    } else if (listItem.objType === 'folder') {
                        return checkIfDashInFolderIsHidden(dashboardsHideModel);
                    }
                }

                function hideSharedDashboardForNonOwner() {
                    dashboardHideService.getDashboardsHideModel()
                        .then(function(dashboardsHideModel) {
                            if (isListItemHidden(dashboardsHideModel)) {
                                (lmnt).hide();
                            }
                        });
                }

                if (prism.user._id !== listItem.owner) {

                    hideDrilledDashboards();

                    if (appConfig.hideSharedDashboardsForNonOwner) {
                        hideSharedDashboardForNonOwner();
                    }
                }
            }
        }
    }
]);