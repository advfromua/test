mod.directive('widgetBody', [
    'plugin-jumpToDashboard.services.displayAndGetDashboardsFunctions',
    "plugin-jumpToDashboard.services.bindOnce",
    function ($displayAndGetDashboardsFunctions, $bindOnce) {
        return {
            restrict: 'C',
            link: function link($scope, lmnt) {
                var widget = $scope.widget;
                var isBloxRenderFirstTime = true;
                var isBlox = widget.type === "BloX";

                function addIconToWidgetTitle(iconContainer, widgetElement) {
                    if (iconContainer.hasClass("ng-hide")) {
                        iconContainer.removeClass("ng-hide");
                    }
                    var title = iconContainer.text();
                    iconContainer.html("<div class='jtd-title-img'/>");
                    iconContainer.append(title);
                    widgetElement.addClass("jumpable");
                }

                function onWidgetDomReady(widget) {
                    if (isBlox) {
                        if (!isBloxRenderFirstTime) {
                            return;
                        }
                        isBloxRenderFirstTime = false;
                    }

                    var widgetElement = $($(lmnt).closest(".widgetWrapper")[0]);
                    var iconContainer = $(widgetElement.find(".widgetHeadline"));
                    var config = $displayAndGetDashboardsFunctions.getWidgetJTDConfig(widget, appConfig);
                    var isWidgetCanJump =
                        iconContainer.length && config.showJTDIcon
                        && (widget.options.drillTarget || config.dashboardIds.length)
                        && widget.type !== "richtexteditor";

                    if (isWidgetCanJump) {
                       addIconToWidgetTitle(iconContainer, widgetElement);
                    } else {
                        widgetElement.removeClass("jumpable");
                    }
                }

                if (isBlox) {
                    $bindOnce(widget, "render", onWidgetDomReady);
                } else {
                    $bindOnce(widget, "domready", onWidgetDomReady);
                }
            }
        }
    }
]);
