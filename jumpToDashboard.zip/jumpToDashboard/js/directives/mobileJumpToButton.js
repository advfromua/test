mod.directive("mobileJumpToButton", [
    "$rootScope",
    "plugin-jumpToDashboard.services.jtdForMobileService",
    function ($rootScope, $jtdForMobileService) {
        return{
            restrict: "E",
            replace: true,
            templateUrl: "/plugins/jumpToDashboard/templates/mobileJumpToButton.html",
            link: function (scope) {
                scope.showDashList = false;
                scope.readyToJump = false;
                scope.title = appConfig.drillToDashboardRightMenuCaption;

                scope.openDashboardsList = function($event) {
                    scope.showDashList = true;
                    scope.readyToJump = false;
                    $event.stopPropagation();
                    $event.preventDefault();
                };

                scope.close = function($event) {
                    setTimeout(function () {
                        scope.showDashList = false;
                        scope.readyToJump = false;
                        $event && $event.stopPropagation();
                        $event && $event.preventDefault();
                        scope.$apply();
                    }, 10);
                };

                scope.onDashClicked = function(targetDashboard, $event) {
                    $jtdForMobileService.updateDashFilterAndJump(scope.filters, targetDashboard);
                    scope.close($event);
                };

                $(".dashboardView, .widget-body").click(function(event) {
                    if ($(event.target).closest(".mobileJumpToMenuContainer").length) {
                        event.stopPropagation();
                        event.preventDefault();
                        return;
                    }
                    if (scope.readyToJump) {
                        scope.readyToJump = false;
                        scope.$apply();
                    } else if(scope.showDashList){
                        scope.showDashList = false;
                        scope.$apply();
                    }
                });

                // hiding jumpTo button and menu on hardware back button touch event
                prism.on("softKeyboardBackButtonPressed", function(){
                    scope.close(null);
                });

                $rootScope.$on("jtd:widgetClicked", onWidgetClicked);

                function onWidgetClicked(e, args) {
                    scope.widget = args.widget;
                    scope.filters = args.filters;
                    scope.targetDashboards = args.targetDashboards;
                    scope.readyToJump = true;
                    scope.showDashList = false;

                    scope.$apply();
                }
            }
        }
    }
]);
