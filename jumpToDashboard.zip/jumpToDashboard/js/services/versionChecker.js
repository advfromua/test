mod.service("versionChecker", [
    function () {

        //check current sisense version based on substring comparison or by 'comparator' callback function if exist.
        this.isVersionValid = function(targetVersion, comparatorFn) {

            if (comparatorFn) {

                var patchIndex = 3;
                var targetVersionLevels = targetVersion.split('.');
                var currentVersionLevels = prism.version.split('.');

                currentVersionLevels = currentVersionLevels.slice(0, targetVersionLevels.length);

                if (currentVersionLevels.length === patchIndex + 1) {
                    currentVersionLevels[patchIndex] = currentVersionLevels[patchIndex].slice(0, targetVersionLevels[patchIndex].length)
                }

                return comparatorFn(currentVersionLevels.join(''), targetVersionLevels.join(''));
            }
            else {
                return prism.version.indexOf(targetVersion) === 0;
            }
        };

        this.isVersionGreater = function(targetVersion) {
            return this.isVersionValid(targetVersion, function(currentVersion, targetVersion) {
                return currentVersion > targetVersion;
            })
        };

        this.isVersionGreaterEqual = function(targetVersion) {
            return this.isVersionValid(targetVersion, function(currentVersion, targetVersion) {
                return currentVersion >= targetVersion;
            })
        };

        this.isVersionLower = function(targetVersion) {
            return this.isVersionValid(targetVersion, function(currentVersion, targetVersion) {
                return currentVersion < targetVersion;
            })
        };

        this.isVersionLowerEqual = function(targetVersion) {
            return this.isVersionValid(targetVersion, function(currentVersion, targetVersion) {
                return currentVersion < targetVersion;
            })
        };

        this.isVersionEqual = function(targetVersion) {
            return this.isVersionValid(targetVersion, function(currentVersion, targetVersion) {
                return currentVersion === targetVersion;
            })
        };


    }
]);
