
mod.service(
    "displayAndGetDashboardsFunctions", [
    "plugin-jumpToDashboard.services.filtersHelperService",
    "plugin-jumpToDashboard.services.checkDatasource",
    "plugin-jumpToDashboard.services.httpCommunicateService",
    function ($filtersHelperService, $checkDatasource, $httpCommunicateService) {
        var apiParams = {
            api: 'v1/',
            params: '?fields=oid,title,parentFolder,datasource',
            url: baseUrl
        };
        var self = this;
        var isExplorer = detectIE();
        var dashMenuSizeByDashTitle = [
            {
                className: "XLargeDrillSelected", size: "xl", margin: 0, menuClass: "drillable", drillLeft: false,
                marginRichTextBox: 0, sizeForReachTextBox: 235, sizeForReachTextBoxNoFilterPanel: (isExplorer ? 0 : 200)
            },
            {
                className: "XXLargeDrillSelected",
                size: "xxl",
                margin: (isExplorer ? 0 : 195),
                menuClass: "drillable",
                drillLeft: true,
                marginRichTextBox: -690,
                sizeForReachTextBox: 450,
                sizeForReachTextBoxNoFilterPanel: (isExplorer ? 0 : 200)
            }
        ];

        this.getWidgetJTDConfig = function (widget, globalConfig) {
            var config = _.clone(globalConfig);

            // Adds custom configuration to widget
            if (prism.JTDConfigs[widget.oid]) {
                config = angular.extend(config, prism.JTDConfigs[widget.oid]);
            }

            // Set custom navigation type for pivot widget
            if ($filtersHelperService.isPivot(widget.type) && config.drillToDashboardNavigateTypePivot) {
                config.drillToDashboardNavigateType = config.drillToDashboardNavigateTypePivot;
            }
            // Pie charts without categories gets a left click JTD automatically
            else if($filtersHelperService.isPieChartWithoutCategories(widget)){
                config.drillToDashboardNavigateType = 3;
            }
            // Set custom navigation type for chart widgets
            else if (widget.type.match('^chart') && config.drillToDashboardNavigateTypeCharts) {
                config.drillToDashboardNavigateType = config.drillToDashboardNavigateTypeCharts;
            }
            // Set custom navigation type for other Type widgets
            else if (otherTypes.indexOf(widget.type) !== -1
                && config.drillToDashboardNavigateTypeOthers) {
                config.drillToDashboardNavigateType = config.drillToDashboardNavigateTypeOthers;
            }

            if (!defined(config.sendPieChartMeasureFiltersOnClick)) {
                config.sendPieChartMeasureFiltersOnClick = true;
            }

            return config;
        };

        //get drilled dashboards with the same data source
        this.getTargetDashboardList = function(widget) {
            var drillMenuItems = [];
            var folderIds = getFolderIds();
            var largestDesignIndex = 0;
            var design = {};
            var config = {
                url: apiParams.url + "/api/" + apiParams.api + "dashboards" + apiParams.params,
                method : 'GET',
                async: false,
                success: function (data) {
                    drillMenuItems = getDashboardsSuccess(widget, folderIds, largestDesignIndex, data);
                    $.extend(design, dashMenuSizeByDashTitle[largestDesignIndex], true);
                }
            };

            // get all dashboards with drilledDashboardPrefix or dashboards inside a folder matches drilledDashboardsFolderPrefix
            $httpCommunicateService.httpCommunicate(config, true);

            return {
                items: drillMenuItems,
                design: design
            };
        };

        this.checkIfJumpable = function(widget) {
            return $$get(widget, 'options.drillTarget.oid', null)
                || $$get(widget, 'drillToDashboardConfig.dashboardIds.length', 0);
        }

        function modifyPivot2Cells(widget, isDrillEnabled) {
            var widgetConfig = widget.drillToDashboardConfig;

            var linkStyle =  {
                color: '#1FAFF3',
                cursor: 'pointer'
            };

            widget.transformPivot({ type: ['value'] }, function(metadata, cell) {
                if (isDrillEnabled && cell.value) {
                    cell.style = cell.style || {};
                    cell.style = Object.assign({}, cell.style, linkStyle);
                }

                if (widgetConfig && widgetConfig.forceZeroInsteadNull && !cell.value) {
                    cell.value = 0;
                }
            });
        }

        this.applyJTDForPivot2 = function(widget) {
            var PIVOT_CLICK_NAVIGATE_TYPE = 2;
            if (widget.type === "pivot2" && $$get(widget, 'drillToDashboardConfig.drillToDashboardNavigateTypePivot', 0) === PIVOT_CLICK_NAVIGATE_TYPE) {
                modifyPivot2Cells(widget, !!self.checkIfJumpable(widget));
            }
        }

        //save 'drill to dashboard' id
        function drillTo(widget) {
            if (this.checked) {
                delete widget.options.drillTarget;
                this.checked = false;

                var element = getWidgetElement(widget);

                try {
                    $(element).unbind("click", $._data($(element)[0]).handlerFunc);
                    $(element).removeClass("clickable");
                } catch (ex) {
                }
            }
            else {
                widget.options.drillTarget = {oid: this.oid, caption: this.caption, folder: this.folder};
            }

            self.applyJTDForPivot2(widget);

            if (widget.type === 'richtexteditor') {
                // saves all changes to mongo
                widget.changesMade("drillTarget", 'options');
            }

            widget.refresh();
        }

        function getDashboardsSuccess(widget, folderIds, largestDesignIndex, data) {
            var currDS = widget.dashboard.oid;
            var drillTarget = widget.options.drillTarget;
            var targetDashboardId = $$get(drillTarget, 'oid');
            var drillMenuItems = [];

            _.each(data, function (item) {
                var folderNamePrefix = widget.drillToDashboardConfig.drilledDashboardsFolderPrefix;
                var dbnamePrefix = widget.drillToDashboardConfig.drilledDashboardPrefix;

                var title;
                var folder = _.find(folderIds, function (folder) {
                    return item.parentFolder
                        && (item.title.match(dbnamePrefix)
                            || folder.name.match(folderNamePrefix))
                        && folder.oid === item.parentFolder;
                });

                var isNeededDashboard = folderNamePrefix
                    ? (dbnamePrefix
                        ? !!folder || !!item.title.match(widget.drillToDashboardConfig.drilledDashboardPrefix)
                        : !!folder)
                    : !!item.title.match(widget.drillToDashboardConfig.drilledDashboardPrefix);

                var includeDataSource = true;

                if (widget.drillToDashboardConfig.sameCubeRestriction) {
                    includeDataSource = $checkDatasource.checkDatasourceOnMatch(item.datasource, widget.datasource);
                }

                var folderName = $$get(folder, 'name') || '';

                if (item.oid !== currDS && includeDataSource && isNeededDashboard) {
                    if (item.parentFolder && appConfig.showFolderNameOnMenuSelection) {
                        title = folderName + "\\" + item.title;
                    } else {
                        title = item.title;
                    }

                    var menuItemDesign = calculateMEnuSizeToDashTitle(title.length);
                    largestDesignIndex = dashMenuSizeByDashTitle.indexOf(menuItemDesign) > largestDesignIndex ? dashMenuSizeByDashTitle.indexOf(menuItemDesign) : largestDesignIndex;

                    var isSelected = appConfig.drillToDashboardByName
                        ? item.title === $$get(drillTarget, 'caption')
                        : item.oid === targetDashboardId;

                    var targetDashboardMenuItem = {
                        caption: title,
                        desc: title,
                        type: 'check',
                        checked: isSelected,
                        oid: item.oid,
                        folder: item.parentFolder
                    };

                    targetDashboardMenuItem.execute = drillTo.bind(targetDashboardMenuItem, widget);

                    drillMenuItems.push(targetDashboardMenuItem);
                }
            });

            return drillMenuItems;
        }

        // get all folders ids or folder ids for folders which name matches drilledDashboardsFolderPrefix
        function getFolderIds() {
            var folderIds = [];
            var config = {
                type: "GET",
                url: apiParams.url + "/api/folders",
                async: false,
                success: function (data) {
                    data.forEach(function (item) {
                        folderIds.push({oid: item.oid, name: item.name});
                    });
                }
            };

            $httpCommunicateService.httpCommunicate(config, true);

            return folderIds;
        }

        function detectIE() {
            var ua = window.navigator.userAgent;

            // Test values; Uncomment to check result �

            // IE 10
            // ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';

            // IE 11
            // ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';

            // IE 12 / Spartan
            // ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';

            // Edge (IE 12+)
            // ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';

            return /MSIE|Trident|Edge/.test(ua);
        }

        function calculateMEnuSizeToDashTitle(titleLength) {
            if (titleLength <= 26) {
                return dashMenuSizeByDashTitle[0];
            } else {
                return dashMenuSizeByDashTitle[1];
            }
        }
    }
]);
