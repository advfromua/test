mod.service("jtdForMobileService", [
    "$compile",
    "$rootScope",
    "plugin-jumpToDashboard.services.displayAndGetDashboardsFunctions",
    "plugin-jumpToDashboard.services.getFiltersForMobile",
    "plugin-jumpToDashboard.services.bindOnce",
    "plugin-jumpToDashboard.services.filtersHelperService",
    function ($compile, $rootScope, $displayAndGetDashboardsFunctions, $getFiltersForMobile, $bindOnce, $filtersHelperService) {
        var self = this;

        function getTargetDashboards (widget) {
            var JTDConfigs = prism.JTDConfigs[widget.oid];
            var dashboardsFromScript = JTDConfigs ? JTDConfigs.dashboardIds : [];
            var drillTarget = widget.options.drillTarget;

            return drillTarget ? [drillTarget] : dashboardsFromScript;
        }

        function createNewMobileJumpButton () {

            if ($('.mobileJumpToMenuContainer').length) return;

            var button = $compile("<mobile-jump-to-button></mobile-jump-to-button>")($rootScope.$new());

            $(".dashboardChildViewContainer").append(button);
        }

        function createPivotLinks () {
            var cells = $(".pane[state='dashboard.widget'] pivot").find("td.p-value"); // take always last which is a widget veiw

            cells.each(function () {
                $(this).find('div.p-value').html('<a href="javascript:void(0);">' + $(this).find('div.p-value').text() + '</a>');
            })
        }

        function getTargetDashboardOid (currentRowIndex, targetDashboards, widget) {
            var matchedPanelItem = _.find(widget.metadata.getEnabledItems(), function(item){
                return item.field.index === currentRowIndex;
            });
            var matchedTitle = $$get(matchedPanelItem, 'jaql.title');
            var targetDashboard = _.find(targetDashboards, function (item){
                return item.pivotColumnTitle === matchedTitle;
            });

            return $$get(targetDashboard, 'dashboardId');
        }

        function getDrillTargetForPivot(target, targetDashboards, args, drillTarget) {
            // if pivot have different links with different target dashboards
            if (targetDashboards && args.navigateByClick) {
                var targetElement = target.tagName === "A" ? target.parentElement.parentElement : target;
                var currentRowIndex = parseInt($$get($(targetElement),'0.attributes.fidx.value'));

                return {
                    oid: getTargetDashboardOid(currentRowIndex, targetDashboards, args.widget)
                }
            } else {
                return drillTarget;
            }
        }

        function getValueCell (target) {
            var pivotCell = $(target).closest("td")[0];

            return pivotCell && $(pivotCell).hasClass("p-value");
        }

        function onDataPointClick (ev, eventData) {
            var target = ev.target;
            var isValueCell = false; // check if need jump without right click from value cell
            var drillTarget = eventData.widget.options.drillTarget;
            var getFilters = $getFiltersForMobile.getAllFilters;
            var targetDashboards = eventData.widget.drillToDashboardConfig.targetDashboards;
            var jumpByTouch = eventData.jumpOnClickWidgetTypes && drillTarget;
            var isPhantomCell = false;

            Promise.resolve()
                .then(function() {
                    if (target) {
                        isPhantomCell = target.classList[0] === "phantom";
                        return getFilters(target, eventData.widget, eventData.isPivot, eventData.jumpOnClickWidgetTypes, null, drillTarget.oid);

                    } else {
                        // for line chart
                        var selectionData = eventData.pointScope.selectionData;
                        // pass null as first  argument only for line chart, because selectionData already exist
                        return getFilters(null, eventData.widget, eventData.isPivot, eventData.jumpOnClickWidgetTypes, selectionData, drillTarget.oid);
                    }
                })
                .then(function(_filters) {
                    var filters = _filters || [];
                    if (eventData.isPivot) {
                        isValueCell = getValueCell(target);
                        drillTarget = getDrillTargetForPivot(target, targetDashboards, eventData, drillTarget);
                    }

                    var isValueCellWithoutPhantom = isValueCell && !isPhantomCell;
                    var jumpWithoutMenu = jumpByTouch && (isValueCellWithoutPhantom || !eventData.isPivot) && (eventData.navigateByClick || !eventData.isPivot);
                    var jumpWithMenu = filters.isMemberClicked && !isValueCell && !isPhantomCell && !eventData.navigateByClick;

                    if (jumpWithoutMenu)  {
                        ev.preventDefault && ev.preventDefault();
                        self.updateDashFilterAndJump(filters.filters, drillTarget);
                    } else if(jumpWithMenu){
                        ev.stopPropagation && ev.stopPropagation();
                        // show jump to button
                        $rootScope.$broadcast("jtd:widgetClicked", {
                            targetDashboards: eventData.targetDashboards,
                            widget: eventData.widget,
                            filters: filters.filters
                        });
                    }
                })
        }

        var eventData = {};

        $rootScope.$watch("appstate", function (appstate) {
            if (appstate === "widget") {
                createNewMobileJumpButton();
            } else {
                $('.mobileJumpToMenuContainer').remove();
            }
        });

        // get first members for jump button
        function createFirstMemberLineChart (widget) {
            var selectionData = $(".pane[state='dashboard.widget'] cartesianchart").highcharts().series[0].data[0].selectionData;
            var args = {
                context: {
                    pointScope: {
                        selectionData: selectionData
                    }
                }
            };

            processDataPointClick(widget, args);
        }

        function setEventData (widget, jumpOnClickWidgetTypes, targetDashboards, navigateByClick) {
            eventData = {
                widget: widget,
                isPivot: $filtersHelperService.isPivot(widget.type),
                jumpOnClickWidgetTypes: jumpOnClickWidgetTypes,
                targetDashboards: targetDashboards,
                navigateByClick: navigateByClick
            };
        }

        function getJumpOnClickWidgetTypes (widget) {
            return ['pivot', 'pivot2', 'imageWidget', 'indicator'].indexOf(widget.type) !== -1;
        }

        function getJumpOnClickWidgetTypesSelectorClass (widget) {
            return (widget.$noResults && widget.type !== "imageWidget") ? ".widget-no-result-overlay" : ".widget-body";
        }

        function getContainerClass (widget, jumpOnClickWidgetTypes) {
            return jumpOnClickWidgetTypes ? getJumpOnClickWidgetTypesSelectorClass(widget) :".highcharts-root";
        }

        function setEventListenerForJump (widget) {
            var jumpOnClickWidgetTypes = getJumpOnClickWidgetTypes(widget);
            var targetDashboards = getTargetDashboards(widget);
            var isPivot = $filtersHelperService.isPivot(widget.type);
            var config = $displayAndGetDashboardsFunctions.getWidgetJTDConfig(widget, appConfig);
            var navigateByClick = config.drillToDashboardNavigateType === 2;
            var containerClass = getContainerClass(widget, jumpOnClickWidgetTypes);
            var debounced = _.debounce(processDataPointClick, 100);
            var isAreaOrLineChart = widget.type === "chart/line" || widget.type === "chart/area";

            setEventData(widget, jumpOnClickWidgetTypes, targetDashboards, navigateByClick);

            if (!targetDashboards.length) return;

            if (isPivot && navigateByClick) {
                createPivotLinks(widget);
                // for pivots wich have pagination
                $bindOnce(widget, "domready", function() {
                    createPivotLinks(widget);
                });
            }

            if(isAreaOrLineChart) {
                widget.on('beforedatapointtooltip', debounced);
                createFirstMemberLineChart(widget);
            } else {
                var bound = addContainerClickHandler.bind(null, widget, containerClass, debounced);
                $bindOnce(widget, "domready", bound);
                $(containerClass).click(debounced);
            }
        }

        function addContainerClickHandler (widget, containerClass, processDataPointClick){
            $(containerClass).click(processDataPointClick);
        }

        function processDataPointClick (widget, args){
            eventData.pointScope = $$get(args, "context.pointScope");
            onDataPointClick(widget, eventData);
        }

        //jump to target dashboard with filters and dashboard id from BloX
        this.mobileJumpForBlox = function (widget, dashboardId, cardFilters) {
            var getFilters = $getFiltersForMobile.getAllFilters;
            getFilters(null, widget, false, true, [], dashboardId)
                .then(function(res) {
                    var widgetFilters = res.filters;
                    var drillTarget = {oid: dashboardId};
                    var cardFilters = cardFilters.map(function(filter) {
                        return {jaql: filter.jaql}
                    });
                    var filters = $filtersHelperService.mergeFilters(cardFilters , widgetFilters);

                    return self.updateDashFilterAndJump(filters, drillTarget);
                });
        };

        function handleJumpForBloxWidget(widget) {
            widget.drilledDashboardDisplay.jumpFromAction = self.mobileJumpForBlox.bind(this, widget);
        }

        function mobileWidgetReadyForJTD (ev, args) {
            var widget = $$get(args, 'prismWidget.$$model', {});

            if (widget.type === "BloX") {
                handleJumpForBloxWidget(widget);
                return;
            }

            setEventListenerForJump(widget);
        }

        this.init = function(){
            prism.on("mobileWidgetReadyForJTD", mobileWidgetReadyForJTD);
        };

        function onUpdateDashboardFilterSuccess (dashboardId) {
            if (dashboardId) {
                window.sisenseMobileApp.navigateToDashboard(dashboardId);
            }
        }

        function onUpdateDashboardFilterError (err) {
            console.error(err);
        }

        this.updateDashFilterAndJump = function (filters, targetDashboard) {
            if (!targetDashboard) {
                return;
            }
            // in widget script dashboard ids are defined through ID property instead of OID.
            var dashboardId = targetDashboard.oid || targetDashboard.id;
            var onSuccess = onUpdateDashboardFilterSuccess.bind(this, dashboardId);
            var filtersString = {filters: filters};
            var updateDashboardFilters = $filtersHelperService.updateDashboardFilters;

            return updateDashboardFilters(filtersString, dashboardId, onSuccess, onUpdateDashboardFilterError);
        };
    }
]);
