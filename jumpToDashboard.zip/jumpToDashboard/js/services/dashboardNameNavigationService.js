mod.service('$dashboardNameNavigation', [
    'plugin-jumpToDashboard.services.httpCommunicateService',
    '$dashboard',
    function ($httpCommunicateService, $dashboard) {
        this.getDashboardByName = function (dashName) {
            var config = {
                type: 'GET',
                url: baseUrl + '/api/v1/dashboards?name=' + encodeURIComponent(dashName),
            };

            return $httpCommunicateService.httpCommunicate(config, true)
                .then(function(data) {
                    console.log('getDashboardByName', data);
                    return _.first(data) || null;
                });
        };

        this.getDashboard = function (dashboardId) {
            return $dashboard.getDashboard(dashboardId)
                .catch(function (err) {
                    if (err.status === 404) {
                        popNotFoundModal();
                    }
                    throw err;
                });
        };

        this.updateDashboard = function (dashboard, properties) {
            $dashboard.updateDashboard(dashboard, properties);
        }

        this.getDrilledDashboardId = function(drilledDashboardModel) {
            return appConfig.drillToDashboardByName
                ? drilledDashboardModel.oidByName
                : drilledDashboardModel.oid || drilledDashboardModel.id;
        };
    }]);
