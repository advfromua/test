mod.service("getFiltersForMobile", [
    "plugin-jumpToDashboard.services.displayAndGetDashboardsFunctions",
    "plugin-jumpToDashboard.services.filtersHelperService",
    function ($displayAndGetDashboardsFunctions, $filtersHelperService) {

        function getPanelValuesFotScatterChart(widget) {
            var panels = widget.metadata.panels;
            var allowPanelNames = ["x-axis", "y-axis", "point", "Break By / Color"];
            var panelValues = [];

            panels.forEach(function (panel) {
                if (allowPanelNames.indexOf(panel.name) !== -1 && panel.items[0]) {
                    panelValues.push(panel.items[0]);
                }
            });

            return panelValues;
        }

        function getPanelValues (widget) {
            if (widget.type === "chart/pie" || widget.type === "chart/column"
                || widget.type === "chart/bar" || widget.type === "chart/polar") {
                    return widget.metadata.panel("categories").items;
            } else if(widget.type === "chart/line" || widget.type === "chart/area") {
                    return widget.metadata.panel("x-axis").items;
            } else if(widget.type === "chart/scatter") {
                    return getPanelValuesFotScatterChart(widget);
            } else if(widget.type === "trelliswidget") {
                return widget.metadata.panel("break by").items;
            } else {
                return [];
            }
        }

        function getFiltersWithSelectionMembers(widget, selectionData) {
            var panelValues = getPanelValues(widget);
            var membersFilters = [];
            var isScatterChart = widget.type === "chart/scatter";

            panelValues.forEach(function (filter, index) {
                var memberFilter = $$.object.clone(filter, true);

                memberFilter.jaql.filter = {
                    "explicit": true,
                    "multiSelection": true,
                    "members": [selectionData[index]]
                };

                if (isScatterChart) {
                    var isRightPanelForSend = filter.jaql && !(filter.jaql.agg || filter.jaql.formula);
                    isRightPanelForSend && membersFilters.push({jaql: memberFilter.jaql});
                } else {
                    membersFilters.push({jaql: memberFilter.jaql});
                }
            });

            return membersFilters;
        }

        // scatter chart takes members from y-axis, point and break-by without x-axis
        function deleteFirstMemberInScatterChartAndEmptyValues(pointData) {
            var pointDataWithoutFirstProperty = [];
            for(index in pointData) {
                pointData[index] &&
                pointDataWithoutFirstProperty.push(pointData[index]);
            }
            return pointDataWithoutFirstProperty;
        }

        function getPointSelectionData(target, widget){
            var isScatter = widget.type === "chart/scatter";
            var pointData = $$get(target, "point.selectionData", []);
            return isScatter ? deleteFirstMemberInScatterChartAndEmptyValues(pointData) : pointData;
        }

        this.getAllFilters = function(targetOrSeriesName, widget, isPivot, jumpOnClickWidgetTypes, selectionData, dashboardId) {

            var config = $displayAndGetDashboardsFunctions.getWidgetJTDConfig(widget, appConfig);
            var dashFilters = $filtersHelperService.getFilters(widget, targetOrSeriesName);
            var widgetFilters = [];
            var excludeFilterDims = config.excludeFilterDims;
            var includeFilterDims = config.includeFilterDims;
            var mergeTargetDashboardFilters = config.mergeTargetDashboardFilters;

            if (isPivot) {
                widgetFilters = $filtersHelperService.getCellFilters(widget, targetOrSeriesName);
            } else {
                selectionData = selectionData || getPointSelectionData(targetOrSeriesName, widget);
                widgetFilters = getFiltersWithSelectionMembers(widget, selectionData);
            }

            var filters = $filtersHelperService.mergeFilters(widgetFilters, dashFilters);

            // remove all events in cascade filters for correct work
            filters.forEach(function(filter) {
                if (filter.isCascading) {
                    delete filter.model.$$events
                }
            });

            return Promise.resolve()
                .then(function() {
                    if (mergeTargetDashboardFilters) {
                        return $filtersHelperService.mergeTargetDashFilters(filters, dashboardId);
                    }
                    return filters;
                })
                .then(function (_filters) {
                    var filters = $filtersHelperService.filterByExludeOrIncludeFilter(_filters, excludeFilterDims, includeFilterDims);

                    // check availability selected members or special type for success jump
                    var defineFilters = jumpOnClickWidgetTypes && !isPivot
                        ? (jumpOnClickWidgetTypes || defined(widgetFilters[0].jaql))
                        : defined(widgetFilters[0].jaql.filter.members[0]);

                    return {
                        filters: filters,
                        isMemberClicked: defineFilters
                    }
                });
        }
    }
]);