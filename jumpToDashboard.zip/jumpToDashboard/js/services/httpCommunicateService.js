mod.service('httpCommunicateService', [
    '$http',
    function($http) {
        var decorateWithCsrf = function(obj)  {
            var $component = prism.$injector.get('$component');

            return $component.getRootEventTarget().getService('CsrfService').decorate(obj);
        };

        var extendHeaders = function(config) {
            if (!config || typeof config !== 'object') {
                config = { headers: {}};
            }
            if (!config.headers) {
                config.headers = {};
            }
            config.headers['Internal'] = 'true';

            return config;
        };

        var configureWitchCsrf = function() {
            config = extendHeaders(config);
            config.headers = decorateWithCsrf(config.headers);

            return config;
        };

        this.httpCommunicate = function (config, jqueryConfigStyle) {
            var prismHasInternalHttp = prism.$injector.has('base.factories.internalHttp');
            var $component = prism.$injector.get('$component');
            var parentEvent = $component.getParentEventTarget();
            var environment = parentEvent.getEnvironment();
            var isTokenBasedAuth = environment.isTokenBasedAuth_ instanceof Function && environment.isTokenBasedAuth_();

            if (environment && isTokenBasedAuth) {
                if (!config.headers) {
                    config.headers = {}
                }
                config.headers.Authorization = environment.getWebSessionToken();
                config.headers.Initialiser = environment.getHashedWebAccessToken();
            }

            if (prismHasInternalHttp) {
                var $internalHttp = prism.$injector.get('base.factories.internalHttp');

                return $internalHttp(config, jqueryConfigStyle);
            } else if (!prismHasInternalHttp && jqueryConfigStyle) {
                var prismHasComponentService = prism.$injector.has('$component');

                return $.ajax(prismHasComponentService ? configureWitchCsrf(config) : config);
            } else {
                return $http(extendHeaders(config));
            }
        }
    }
]);


