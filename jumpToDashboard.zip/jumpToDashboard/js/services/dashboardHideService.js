mod.service("dashboardHideService", [
    '$q',
    'ux-controls.services.$popper',
    'plugin-jumpToDashboard.services.httpCommunicateService',
    function ($q, $popper, $httpCommunicateService) {
        var dashboardsModelPromise;
        var hideForViewerStrings = {
            title: 'Hide',
            descriptionItemDashboard: 'Hide dashboard for non-owners',
            descriptionItemFolder: 'Hide dashboards for non-owners',
            descriptionMultiSelect: 'Hide for non-owners',
            messageListItemDashboard: 'Are you sure you want to change the visibility of the dashboard for non-owners? It will be automatically republished.',
            messageListItemFolder: 'Are you sure you want to change the visibility of all folder\'s items for non-owners? The changes will be applied to all child dashboards from current folder and sub-folders. It will be automatically republished.',
            messageSelectedSingleDash: 'Are you sure you want to hide the selected dashboard for non-owners? It will be automatically republished.',
            messageSelectedMultipleDash: 'Are you sure you want to hide the selected dashboards for non-owners? It will be automatically republished.'
        };
        var hideFlagAttr = 'hiddenForNonOwner';

        this.hideFlagAttr = hideFlagAttr;
        this.hideForViewerStrings = hideForViewerStrings;

        // loads dashboards model with 'hide for non-owners' flag and other properties
        this.init = function () {
            /* Before we used path: "proxyUrl + '/api/v1/dashboards/?fields=oid,' + hideFlagAttr",
                but due to issues with api in versions 7.2+ we changed path to "proxyUrl + '/api/v1/dashboards/"
            */
            var config = {
                method: 'GET',
                url: proxyUrl + '/api/v1/dashboards/?fields=hiddenForNonOwner,oid'
            };

            dashboardsModelPromise = $httpCommunicateService.httpCommunicate(config)
                .then(function (response) {
                    return response.data.map(function (dashboard) {
                        return {
                            oid: dashboard.oid,
                            hiddenForNonOwner: dashboard.hiddenForNonOwner
                        }
                    });
                }).catch(function (err) {
                    console.error(err);
                });

            return dashboardsModelPromise;
        };

        this.getDashboardsHideModel = function () {
            return dashboardsModelPromise;
        };

        // update hide flag value and republish dashboards
        this.changeDashboardsHideAttr = function (dashboards, hiddenFlagValue) {

            dashboards.forEach(function (dashboard) {
                setHideForViewerProperty(dashboard, hiddenFlagValue);
            });

            updateDashboardsModel(dashboards);

            return $q.all(dashboards.map(function (dashboard) {
                return $q.resolve()
                    .then(function () {
                        return updateDashboardAttr(dashboard.oid, setHideForViewerProperty({}, hiddenFlagValue))
                    })
                    .then(function () {
                        return republishDashboard(dashboard.oid);
                    });
            }));
        };

        function getListItem(args) {
            return $$get(args, "settings.scope.listItem")
                || $$get(args, "settings.scope.dashboard")
                || $$get(args, "settings.scope.activeDashboard");
        }

        this.beforeMenuHandler = function (ev, args) {

            var _this = this;
            var target = $($$get(args, "ui.target"));
            var listItem = getListItem(args);
            var isNavverDashboardMenu = target.hasClass("navver-menu") && listItem;
            var isTileDashboardMenu =  target.hasClass('tile-item__toolbar-btn') && listItem;
            var isRowDashboardMenu =  target.hasClass('home__table-view__action-button') && listItem;
            var isDashboardMenu = $$get(args, "settings.name") === 'dashboard';
            var isRightMenuForHideOption = isRowDashboardMenu || isTileDashboardMenu || isNavverDashboardMenu || isDashboardMenu;
            var dashboards = [];

            if (isNavverDashboardMenu || isTileDashboardMenu || isRowDashboardMenu) {
                dashboards = _this.getNavverItemDashboards(listItem);
            } else if (isDashboardMenu) {
                dashboards = _.compact([prism.activeDashboard]);
            }

            // hides "featured dashboard" menu item for prefixed dashboards
            var listOfMenuItems = args.settings.items;
            var mobileFeatureListItemId = "toggleMobileFeatureList";
            if (isDashboardMenu){
                var targetDashboard = dashboards[0];
                if(this.hasPrefix(targetDashboard.title, appConfig.drilledDashboardPrefix)){
                    var menuItemsWithoutFeatureLine = listOfMenuItems.filter(function(mi){
                        return mi.id !== mobileFeatureListItemId;
                    })
                    args.settings.items = menuItemsWithoutFeatureLine;
                }
            }
            //

            // Collect only own dashboards
            dashboards = dashboards.filter(function(dashboard) {
                return dashboard.owner === prism.user._id;
            });

            if (appConfig.hideSharedDashboardsForNonOwner && isRightMenuForHideOption && dashboards.length) {

                this.getDashboardsHideModel()
                    .then(function (dashboardsHideModel) {

                        var isChecked = dashboards.every(function (item) {
                            var dashboard = _.find(dashboardsHideModel, _.matcher({oid: item.oid}));
                            return $$get(dashboard, hideFlagAttr);
                        });
                        var isSingleDashboard = dashboards.length === 1;

                        args.settings.items.push({type: 'separator'});

                        args.settings.items.push({
                            type: "check",
                            checked: isChecked,
                            confirm: {
                                critical: true,
                                message: hideForViewerStrings.title,
                                subMessage: isSingleDashboard ? hideForViewerStrings.messageListItemDashboard : hideForViewerStrings.messageListItemFolder
                            },
                            command: {
                                title: hideForViewerStrings.title,
                                desc: isSingleDashboard ? hideForViewerStrings.descriptionItemDashboard : hideForViewerStrings.descriptionItemFolder,
                                canExecute: function () {
                                    return true;
                                },
                                execute: function () {
                                    _this.changeDashboardsHideAttr(dashboards, !isChecked);
                                }
                            }
                        });
                    });
            }
        }.bind(this);

        // pop confirmation message and apply changes
        this.popHideForViewerConfirmation = function (event, selectedDashboards) {

            var _this = this;
            var isSingleDashboard = selectedDashboards.length === 1;

            $popper.popConfirmation(
                hideForViewerStrings.title,
                isSingleDashboard ? hideForViewerStrings.messageSelectedSingleDash : hideForViewerStrings.messageSelectedMultipleDash,
                event,
                function () {
                    _this.changeDashboardsHideAttr(selectedDashboards, true);
                },
                function () {
                },
                {target: event.currentTarget}
            );

        };

        // get list of dashboards from navver item (dashboard or folder);
        this.getNavverItemDashboards = function (item) {
            var _this = this;

            if (item.objType === 'dashboard') {
                return [_.pick(item, 'oid', 'owner')];
            }
            else if (item.objType === 'folder') {
                var currentLevelDashboards = $$get(item, 'dashboards', []).map(function (dashboard) {
                    return _.pick(dashboard, 'oid', 'owner');
                });

                var subLevelDashboards = $$get(item, 'tags', []).reduce(function (acc, folderItem) {
                    return acc.concat(_this.getNavverItemDashboards(folderItem));
                }, []);

                return currentLevelDashboards.concat(subLevelDashboards);
            }
            else {
                return [];
            }
        };

        //  function returns bool if string starts with prefix or not. If prefix empty, than return false
        this.hasPrefix = function(str, prefix) {
            return prefix && str.indexOf(prefix) === 0;
        };

        //  function returns bool if dashboard in folder that has prefix
        this.isDashInPrefixedFolder = function(node, prefix) {
            var parentName = $$get(node, 'parentFolderNode.name', '');
            return this.hasPrefix(parentName, prefix) || node && this.isDashInPrefixedFolder(node.parentFolderNode, prefix);
        };

        //  if item has prefix -> hide it
        this.hidePrefixedListItem = function (item, lmnt) {
            var hideDashboard = item.objType === 'dashboard' && this.hasPrefix(item.title, appConfig.drilledDashboardPrefix),
                hideFolder = item.objType === 'folder' && this.hasPrefix(item.title, appConfig.drilledDashboardsFolderPrefix);

            if (hideDashboard || hideFolder) {
                $(lmnt).hide();
            }
        };

        function updateDashboardAttr(oid, data) {
            var config = {
                method: 'PATCH',
                url: proxyUrl + '/api/v1/dashboards/' + oid,
                data: data
            };

            return $httpCommunicateService.httpCommunicate(config)
                .then(function (response) {
                    return response;
                })
                .catch(function (err) {
                    console.error(err);
                });
        }

        function republishDashboard(oid) {
            var config = {
                method: 'POST',
                url: proxyUrl + '/api/v1/dashboards/' + oid + '/publish?force=true',
                data: null
            };

            return $httpCommunicateService.httpCommunicate(config)
                .then(function (response) {
                    return response;
                })
                .catch(function (err) {
                    console.error(err);
                });
        }

        // update dashboards model with changed "hide for non-owners" flags
        function updateDashboardsModel(dashboards) {
            return dashboardsModelPromise
                .then(function (model) {
                    var updatedData = _.uniq(dashboards.concat(model), false, _.property('oid'));
                    dashboardsModelPromise = $q.resolve(updatedData);
                    return dashboardsModelPromise;
                })
        }

        function setHideForViewerProperty(object, value) {
            object[hideFlagAttr] = value;
            return object;
        }

        this.hideDrilledDashboards = function (items) {
            var _this = this;
            var allowedItems = items.filter(function (item) {
                var isDashOwner = prism.user._id === item.owner,
                    isHiddenByDashPrefix = _this.hasPrefix(item.title, appConfig.drilledDashboardPrefix),
                    isHiddenByFolderPrefix = _this.isDashInPrefixedFolder(item, appConfig.drilledDashboardsFolderPrefix);
                return isDashOwner || !isHiddenByDashPrefix && !isHiddenByFolderPrefix;
            });

            return allowedItems.length !== items.length ? allowedItems : items;
        };

        this.hideSharedDashboardsForNonOwner = function (dashboards, items) {
            var _this = this;
            var allowedItems = items.filter(function (item) {
                var dashboard = _.find(dashboards, _.matcher({oid: item.oid}));
                return !$$get(dashboard, _this.hideFlagAttr) || prism.user._id === item.owner;
            });
            return allowedItems.length !== items.length ? allowedItems : items;
        };

    }]);
