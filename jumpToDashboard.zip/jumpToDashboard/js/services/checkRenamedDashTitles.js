mod.service("checkRenamedDashTitles", [
    '$dashboard',
    'navver.services.navverService',
    function ($dashboard, navverService) {

        function getDahboardsFromFolder(model, dashboardArr) {
            var folders = model.tags;

            if (folders && folders.length) {
                return folders.map(function(folder) {
                    return dashboardArr.concat(getDahboardsFromFolder(folder, folder.dashboards || []));
                })
            } else {
                return dashboardArr;
            }
        }

        function generateObjWithDashTitles(dashboards, dashboardsObjectWithTitles) {
            dashboards.forEach(function (dashboard) {
                dashboardsObjectWithTitles[dashboard.oid] = dashboard.title;
            });

            return dashboardsObjectWithTitles;
        }

        function updateDrillTargetTitle(widget, drillTarget, newTitle) {
            widget.options.drillTarget = {
                oid: drillTarget.oid,
                caption: newTitle,
                folder: drillTarget.folder
            };

            $dashboard.updateWidget(widget, 'options');
        }

        this.checkTargetDashName = function(widget) {
            var navverModel = navverService.model;
            var dashboards = navverModel.dashboards;
            var dashboardsObjectWithTitles = {};
            var drillTarget = widget.options.drillTarget;

            if (navverModel.tags.length) {
                var dashboardsFromFolders = _.flatten(getDahboardsFromFolder(navverModel, []));
                dashboards = dashboards.concat(dashboardsFromFolders);
            }

            dashboardsObjectWithTitles = generateObjWithDashTitles(dashboards, dashboardsObjectWithTitles);

            var newCaption = dashboardsObjectWithTitles[drillTarget.oid] || widget.options.drillTarget.caption;

            var titleRenamed = newCaption !== drillTarget.caption;

            if (drillTarget && titleRenamed) {
                updateDrillTargetTitle(widget, drillTarget, dashboardsObjectWithTitles[drillTarget.oid]);
            }

            return newCaption;
        };
    }
]);
