mod.service("filtersHelperService", [
    'plugin-jumpToDashboard.services.httpCommunicateService',
    'plugin-jumpToDashboard.services.$dashboardNameNavigation',
    function($httpCommunicateService, $dashboardNameNavigation) {
        var self = this;
        var apiParams = {
            api: 'v1/',
            url: baseUrl
        };

        // make all cascade filters as individual filters
        function getFlattenFilters(sourceFilters) {
            return sourceFilters && sourceFilters.reduce(function (acc, filter) {
                var filtersToAdd = [filter];

                if (filter.isCascading) {
                    filtersToAdd = filter.levels.map(function (levelJaql) {
                        return {
                            jaql: levelJaql
                        }
                    });
                }

                return acc.concat(filtersToAdd);
            }, []);
        }

        /* sorts source filters by uniqueness relative to target filters
         and return object with two property filtersUniq an filtersToMerge */
        function getSourceFiltersGroups(sourceFilters, targetFiltersFlatten) {
            return _.groupBy(sourceFilters, function (filter) {
                var isCascadingFilterUniq = filter.isCascading && filter.levels.every(function (levelJaql) {
                    return targetFiltersFlatten.every(function (targetFilter) {
                        return targetFilter.jaql.dim !== levelJaql.dim;
                    });
                });

                return isCascadingFilterUniq ? 'filtersUniq' : 'filtersToMerge';
            });
        }

        // get widget filters together with measured filters (those which are set up in formula)
        function getWidgetFilters(widget, targetOrSeriesName) {
            var measuredFilters = [];
            var widgetFilters = widget.metadata.filters().filter(function(item) {
                return item.jaql && item.jaql.dim
            });
            var valuesPanel = widget.metadata.panel("values");
            var valuePanel = widget.metadata.panel("value");
            var seriesName = typeof targetOrSeriesName === "string" ? targetOrSeriesName : (self.isPieChartWithoutCategories(widget) ? $$get(targetOrSeriesName, "point.name")
                : $$get(targetOrSeriesName, "point.series.name"));
            var breakByPanel = widget.metadata.panel("break by");

            // var isPieChartWithNoCategories = isPieChartWithoutCategories(widget);

            if (valuesPanel && seriesName) {
                var panelItem;

                if ($$get(breakByPanel, "items.length")) {
                    // find active dim from "values" panel when "break by" exist
                    panelItem = _.find(valuesPanel.items, function (item) {
                        return !item.disabled;
                    });
                }
                else {
                    panelItem = _.find(valuesPanel.items, function (item) {
                        var title = $$get(item, "jaql.title");
                        return title && title === seriesName;
                    });
                }

                if (panelItem) {
                    measuredFilters = getMeasuredValueFilters(panelItem);
                }
            }

            // collect measured value filters from "indicator" widget
            if (valuePanel) {
                measuredFilters = getMeasuredValueFilters(valuePanel.items[0]);
            }

            // need to return both here -> disabled are removed after dash filter merge
            return {
                allFilters: measuredFilters.concat(widgetFilters),
                ignoreAll: widget.metadata.ignore.all,
                disabled: widget.metadata.ignore.dimensions
            };
        }

        function getDashboardOrWidgetFilters(dashboardOrWidgetFilters) {
            var filters = [];
            dashboardOrWidgetFilters.forEach(function (f) {

                var filterObj;

                if (f.isCascading) {

                    filterObj = {
                        levels: $.extend(true, [], f.levels),
                        model: $.extend(true, {}, f.model),
                        isCascading: true
                    }

                } else {

                    filterObj = {
                        jaql: $.extend(true, {}, f.jaql)
                    }

                }

                if (f.locked === true) {
                    filterObj.locked = true;
                }

                filterObj.instanceid = f.instanceid;
                filterObj.isCascading = f.isCascading;

                filters.push(filterObj);
            });

            return filters;
        }

        /* iterate through filters and remove those containing duplicate dimensions or add the filter into the cascading
         filter levels which contain duplicate dimension */
        this.getFiltersWithoutDuplicates = function (filters) {
            if (!filters.length) {
                return filters;
            }
            var result = [],
                indexesToRemove = [];

            filters.forEach(function (filterItem, idx) {
                result.push(filterItem);

                if (!filterItem.isCascading && filterItem.jaql.dim) {
                    var remainingFilters = filters.slice(idx + 1);
                    if (!remainingFilters.length) return;

                    var duplicates = findDuplicateFilters(filterItem.jaql, remainingFilters);

                    if (duplicates.length) {
                        if (!filterItem.instanceid) {
                            var itemWithInstanceid = duplicates.find(function (el) {
                                return el.instanceid;
                            });
                            if (itemWithInstanceid) {
                                filterItem.instanceid = itemWithInstanceid.instanceid;
                                filterItem.isCascading = itemWithInstanceid.isCascading;
                            }
                        }

                        if (isLockedFilterInFilters(duplicates)) {
                            result[result.length - 1].locked || (result[result.length - 1].locked = true);
                        }

                        duplicates.forEach(function (f) {
                            if (f.isCascading) {
                                // If filter exists in the cascaded filter, we want to put the value and not adding standalone filter item.
                                replaceCascFilterItem(f, filterItem);
                                // Saving the indexes of the unnecessary filters to remove later.
                                indexesToRemove.unshift(filters.indexOf(filterItem));
                            } else {

                                var index = filters.indexOf(f);
                                if (index < 0) {
                                    return;
                                }
                                filters.splice(index, 1);

                            }
                        })
                    }
                }
            });

            // a loop to remove unnecessary filter items.
            while (indexesToRemove.length !== 0) {
                result.splice(indexesToRemove[0], 1);
                indexesToRemove.shift();
            }

            return result;
        }

        function isLockedFilterInFilters(filters) {
            return ~_.findIndex(filters, function (item) {
                return item.locked
            });
        }

        function replaceCascFilterItem(cascFilter, filterItem) {
            var matchedItem = _.find(cascFilter.levels, function (lvl) {
                return lvl.dim === filterItem.jaql.dim;
            });

            matchedItem.filter = filterItem.jaql.filter;
        }

        // get contexts from formula
        function parseFormulaForContexts(formula) {
            var pattern = /\[(.*?)\]/g;
            return _.uniq(formula.match(pattern));
        }

        // find filters by dimension
        function findDuplicateFilters(jaql, filters) {
            var DATETIME_DATATYPE = "datetime";
            var dim = jaql.dim.toLowerCase();

            return filters.filter(function (item) {
                var filterDim = item.jaql ? item.jaql.dim : null;
                if (item.isCascading) { // for cascading filter find those which contain levels for specific dimension
                    var filters = item.levels.filter(function (filter) {
                        return filter.dim.toLowerCase() === dim && (jaql.datatype === DATETIME_DATATYPE ? filter.level === jaql.level : true);
                    });
                    return !!filters.length;
                }

                return !item.isCascading && filterDim && filterDim.toLowerCase() === dim && (jaql.datatype === DATETIME_DATATYPE ? item.jaql.level === jaql.level : true);
            });
        }

        this.getDashboardFiltersToRestore = function (dashboardOID) {
            var params = "?fields=filters%2Cdatasource%2CfiltersToRestore";
            // get all dashboards with drilledDashboardPrefix or dashboards inside a folder matches drilledDashboardsFolderPrefix
            var config = {
                url: apiParams.url + "/api/"  + apiParams.api + "dashboards/" + dashboardOID + params,
                type: 'GET',
            };

            return $httpCommunicateService.httpCommunicate(config, true)
                .then(function(data) {
                    return data.filtersToRestore || data.filters || [];
                })
                .catch(function (err) {
                    if (err.status === 404) {
                        popNotFoundModal();
                    } else {
                        throw err;
                    }
                });
        };

        this.computeMeasuredValuesFilters = function(metadata) {
            return getMeasuredValueFilters(metadata);
        }

        this.mergeTargetDashFilters = function (sourceFilters, dashboardId) {
            return self.getDashboardFiltersToRestore(dashboardId)
                .then(function(targetFilters) {
                    var targetFiltersFlatten = getFlattenFilters(targetFilters);
                    var sourceFiltersGroups = getSourceFiltersGroups(sourceFilters, targetFiltersFlatten);
                    var sourceFiltersFlatten =
                        sourceFiltersGroups['filtersToMerge'] ? getFlattenFilters(sourceFiltersGroups['filtersToMerge']) : [];
                    var filtersToInsert = [];

                    sourceFiltersFlatten.forEach(function (filter) {
                        var isInserted = false;

                        targetFilters.forEach(function (targetFilter) {
                            if (isInserted) return;

                            if (!targetFilter.isCascading) {
                                if ($$get(targetFilter, 'jaql.dim') === $$get(filter, 'jaql.dim')) {
                                    // current filter replaced by main filter if they have same dims
                                    targetFilter.jaql = filter.jaql;
                                    targetFilter.disabled = filter.disabled;
                                    isInserted = true;
                                }
                            } else if (targetFilter.isCascading) {
                                targetFilter.levels.forEach(function (level, index) {
                                    if ($$get(level, 'dim') === $$get(filter, 'jaql.dim') && $$get(level, 'level') === $$get(filter, 'jaql.level')) {
                                        // current level replaced by main filter if they have same dims
                                        targetFilter.levels[index] = filter.jaql;
                                        isInserted = true;
                                    }
                                })
                            }
                        });

                        if (!isInserted) {
                            filtersToInsert.push(filter);
                        }
                    });

                    return targetFilters.concat(filtersToInsert).concat(sourceFiltersGroups['filtersUniq'] || []);
                });
        };

        function deleteFilterLevelByCondition(filterItem, conditionToRemoveLevel) {
            filterItem.levels = filterItem.levels.filter(function(level) {
                return !conditionToRemoveLevel(level);
            });

            //changes cascading filter to non cascading
            if (filterItem.levels.length == 1) {
                filterItem.jaql = filterItem.levels[0];
                delete filterItem.levels;
                delete filterItem.model;
                filterItem.isCascading = false;
            }
            return filterItem;
        }

        function isFilterNeedForExludeOrInclude(filterItem, filtersDims, isExludeFiltersDims) {
            var filterDim = filterItem.jaql.dim && filterItem.jaql.dim.toLowerCase()

            return !filterItem.jaql.agg && isExludeFiltersDims
                ? filtersDims.indexOf(filterDim) < 0
                : filtersDims.indexOf(filterDim) >= 0;
        }

        function getExcludeOrIncludeFilterDims(filtersDims, filters, isExludeFiltersDims) {
            filtersDims = filtersDims.map(function (dim) {
                return dim.toLowerCase()
            });

            var filtersConditionFunction = function (level) {
                return isExludeFiltersDims
                    ? filtersDims.indexOf(level.dim.toLowerCase()) >= 0
                    : filtersDims.indexOf(level.dim.toLowerCase()) < 0;
            };

            return filters.filter(function (filterItem) {
                if (filterItem.isCascading) {
                    filterItem = deleteFilterLevelByCondition(filterItem, filtersConditionFunction);

                    return !!filterItem.levels && !!filterItem.levels.length;
                } else {
                    return isFilterNeedForExludeOrInclude(filterItem, filtersDims, isExludeFiltersDims);
                }
            });
        }

        this.filterByExludeOrIncludeFilter = function (filters, excludeFilterDims, includeFilterDims) {
            if (typeof excludeFilterDims === 'string') {
                excludeFilterDims = excludeFilterDims.split(',');
            }

            if (typeof includeFilterDims === 'string') {
                includeFilterDims = includeFilterDims.split(',');
            }

            if (!excludeFilterDims.length && !includeFilterDims.length) {
                return filters;
            }

            if (excludeFilterDims.length) {
                filters = getExcludeOrIncludeFilterDims(excludeFilterDims, filters, true);
            }

            if (includeFilterDims.length) {
                filters = getExcludeOrIncludeFilterDims(includeFilterDims, filters, false);
            }

            return filters;
        };

        // Create filter object.
        function createFilter(items, fieldIndex, value, widget) {
            var item = {jaql: {}};
            var tmpitem = $.grep(items, function (i) {
                return i.field.index === fieldIndex && !i.disabled
            })[0];

            item.jaql.datatype = tmpitem.jaql.datatype;
            item.jaql.dim = tmpitem.jaql.dim;
            item.jaql.filter = value ? {members: [value]} : {all: true};
            item.jaql.title = tmpitem.jaql.title;
            item.jaql.datasource = widget.datasource;
            item.jaql.table = tmpitem.jaql.table;
            item.jaql.column = tmpitem.jaql.column;

            if (tmpitem.jaql.level) {
                item.jaql.level = tmpitem.jaql.level;
            }

            return item;
        }

        function isLowermostMeasureHeader(classString) {
            return (classString.indexOf("p-measure-head") >= 0 ||
                classString.indexOf("p-total-head") >= 0 &&
                classString.indexOf("p-dim-member") < 0 ||
                classString.indexOf("p-grand-total-head") >= 0);
        }

        function isLowermostHeaderClass(classString) {
            return (classString.indexOf("p-dim-head") >= 0 || isLowermostMeasureHeader(classString));
        }

        function getLowermostHeaderCellsInOrder(table) {
            function scanSubtree(rowIndex) {
                for (; leavesToFindInCurrentSubtree[rowIndex] > 0;) {
                    scanSubtree(rowIndex + rowSpansOfCurrentSubtree[rowIndex]);
                }
                var indexOfCellWithinRow = cellIndices[rowIndex];
                var currentRow = headerRows[rowIndex];

                if (currentRow && !(currentRow.cells.length <= indexOfCellWithinRow)) {
                    var numberOfLeavesInSubtree = parseInt(currentRow.cells[indexOfCellWithinRow].getAttribute("colspan") || 1);
                    var rowSpan = parseInt(currentRow.cells[indexOfCellWithinRow].getAttribute("rowspan") || 1);

                    if ((numberOfLeavesInSubtree > 1 || !isLowermostHeaderClass(currentRow.cells[indexOfCellWithinRow].className)) && headerRows.length >= rowIndex + rowSpan + 1) {
                        leavesToFindInCurrentSubtree[rowIndex] = numberOfLeavesInSubtree || 1;
                        cellIndices[rowIndex]++;
                        rowSpansOfCurrentSubtree[rowIndex] = rowSpan;
                        return void scanSubtree(rowIndex + rowSpan);
                    }

                    elements.push(currentRow.cells[indexOfCellWithinRow]);
                    cellIndices[rowIndex]++;

                    for (var i = 0; rowIndex > i; ++i) leavesToFindInCurrentSubtree[i]--;
                    scanSubtree(0)
                }
            }

            for (var elements = [], headerRows = $(table).find("thead tr:not(.p-fake-measure-head)"), cellIndices = [], leavesToFindInCurrentSubtree = [], rowSpansOfCurrentSubtree = [], i = 0; i < headerRows.length; ++i)
                cellIndices.push(0), leavesToFindInCurrentSubtree.push(0), rowSpansOfCurrentSubtree.push(0);

            scanSubtree(0);

            return elements
        }

        // given a cell, gets the dimension member row cells for that cell, for all row dimensions. (i.e, for a value cell of row 'tel aviv -> israel -> asia', returns the cells for 'tel aviv', 'israel', 'asia')
        // cell can be either a value cell, or a dimension member cell
        function getRowCells(cell, dimensionsContainer) {

            // version 7 fix for pivot jump via right click menu
            if (parseInt(prism.version.charAt(0)) >= 7) {

                $cellNodeName = $(cell).prop('nodeName');

                if ($(cell).is('.wrapper') ||
                    $(cell).is('.p-value') && $cellNodeName === 'DIV') {
                    cell = cell.parentNode;
                }

                if ($(cell).is('.p-head-content')) {
                    cell = cell.parentNode.parentNode;
                }

                if ($cellNodeName === 'SPAN') {
                    cell = cell.parentNode.parentNode.parentNode;
                }

                dimensionsContainer.context = cell;
            }

            var dimCellId = $(cell.parentNode.cells).filter('.p-dim-member:last, .p-total-row-head:last, .p-grand-total-row-head:last').prop('id'); //last dimension is guaranteed to be in the same row as value
            var currCell = cell.className.indexOf('p-dim-member') >= 0 ? cell : dimensionsContainer.find('td[originalid = "' + dimCellId + '"], td#' + dimCellId)[0];	// get corresponding cell in the dimensions container
            var allDimensionMemberCells = $(currCell).parents('tbody').find('td.p-dim-member');
            var rowCells = [];
            var lastFoundCell = currCell;
            var currCellIndex = currCell ? parseInt(currCell.getAttribute('fIdx')) : -1;

            if (currCellIndex === -1) {
                return [];
            }
            if (currCellIndex === 0 || $(currCell).hasClass("p-grand-total-row-head")) {
                return [currCell];
            }

            while (currCellIndex > 0) {
                var currRow = lastFoundCell.parentNode;

                while (!currCell) {
                    currRow = node_before(currRow);

                    if (!currRow) {
                        currCellIndex -= 1;
                        break;
                    }

                    currCell = $(currRow).find('td.p-dim-member[fIdx = ' + (currCellIndex - 1) + ']')[0];
                }

                while (currCell) {
                    currCellIndex = parseInt(currCell.getAttribute('fIdx'));
                    rowCells = $.merge(rowCells, [currCell]);
                    lastFoundCell = currCell;
                    currCell = node_before(currCell);
                }
            }

            return rowCells;
        }

        function node_before(sib) {
            while (sib = sib.previousElementSibling) {
                if (!is_ignorable(sib)) {
                    return sib;
                }
            }
            return null;
        }

        function is_ignorable(nod) {
            return nod.nodeType === 8 || nod.nodeType === 3 && is_all_ws(nod) || nod.className.indexOf("p-fake-measure-head") !== -1;
        }

        function is_all_ws(nod) {
            return !/[^\t\n\r ]/.test(nod.data || nod.innerText);
        }

        function getCellsByIndexAndValue(allCells, fieldIndex, value, isDateTime) {
            function exactTextMatch() {
                return isDateTime ? _.isEqual(Date.parseDate(this.getAttribute("val")), value) : this.getAttribute("val") === value;
            }

            var matchingCells = allCells.filter(exactTextMatch).filter("[fIdx = " + fieldIndex + "], [fDimensionIdx = " + fieldIndex + "]");

            return matchingCells;
        }

        // get measured value filters (those which are set up in formula)
        function getMeasuredValueFilters(measuredValue) {
            var context = $$get(measuredValue, "jaql.context");
            var formula = $$get(measuredValue, "jaql.formula");

            // Breaks and return empty filters list if formula or context not exist
            if (!formula || !context) return [];

            var contextProps = parseFormulaForContexts(formula);

            // Collect filters of each context from formula
            var filters = contextProps.reduce(function (acc, prop) {

                var jaql = context[prop];

                if (jaql.filter) {
                    acc.push({jaql: jaql});
                }

                return acc;
            }, []);

            // Remove redundant filters for same dimension
            return _.uniq(filters, false, function (item) {
                return item.jaql.dim;
            });
        }

        function getCellsFromSameFieldWithSameTextValue(allCells, cell) {
            var value = $(cell).attr("val"), fieldIndex = parseInt(cell.getAttribute("fIdx"));

            return getCellsByIndexAndValue(allCells, fieldIndex, value);
        }

        // given a cell, gets the dimension member column header cells for that cell, for all column dimensions. (i.e for a value cell of column 'ipod nano -> apple' returns 'ipod nano', 'apple'
        // cell can be either a value cell, or a dimension member header cell.
        function getColumnCells(cell, headersContainer, orderedLowermostCells, isLowermostHeaderCell) {
            var columnCells = [];
            var headerCell = cell;
            if (!isLowermostHeaderCell) {
                var indexAmongstValueCells = $(cell).parent().children('td.p-value').index(cell);
                headerCell = _.reject(orderedLowermostCells, function (c) {
                    return c.className.indexOf('p-dim-head') >= 0;
                })[indexAmongstValueCells];
            }

            if (!headerCell) {
                return columnCells;
            }

            // Find appropriate header cells. the lowermost row has the same columns as the values row.
            // Therefore - the cell index would be the same.
            var allDimensionHeaderCells = $(headersContainer).find('td.p-dim-member-head');

            if (headerCell.className.indexOf('p-dim-member-head') < 0) {
                // not a dimension member (a value header)- retrieve the correct dimension header using the measure path, if available
                headerCell = allDimensionHeaderCells.filter('[measurePath = \'' + headerCell.getAttribute('measurePath') + '\']')[0] || headerCell;
            }

            var allCellsWithSameValue = getCellsFromSameFieldWithSameTextValue(allDimensionHeaderCells, headerCell);
            $.merge(columnCells, allCellsWithSameValue);

            var measurePath = headerCell.getAttribute('measurePath');
            if (!measurePath)
                return columnCells;

            var lastIndexOfComma = measurePath.lastIndexOf('","');
            while (lastIndexOfComma > 0) {
                measurePath = measurePath.slice(0, lastIndexOfComma + 1) + '}';
                headerCell = headersContainer.find('thead td[measurePath = \'' + measurePath + '\']')[0];

                allCellsWithSameValue = getCellsFromSameFieldWithSameTextValue(allDimensionHeaderCells, headerCell);
                $.merge(columnCells, allCellsWithSameValue);

                lastIndexOfComma = measurePath.lastIndexOf('","');
            }
            return columnCells;
        }

        //merge filters excluding those with duplicate dimensions
        this.mergeFilters = function (firstFilters, secondFilters) {
            return self.getFiltersWithoutDuplicates($.merge(firstFilters, secondFilters));
        };

        //get cell filters
        this.getCellFilters = function (widget, cell) {

            if (cell.tagName !== "TD") {
                cell = $(cell).closest('td')[0];
            }

            var lowermostCells = getLowermostHeaderCellsInOrder($(cell).parents('table'));
            var colCells = getColumnCells(cell, $(cell).parents('table'), lowermostCells);
            var rowCells = getRowCells(cell, $(cell).parents('table'));
            var itemsIndex;

            if (cell.className.indexOf('p-first-data-col') > -1) {
                var rowsCount = _.filter(widget.metadata.panel("rows").items, function (item) {
                    return !item.disabled;
                }).length;
                var columnsCount = _.filter(widget.metadata.panel("columns").items, function (item) {
                    return !item.disabled;
                }).length;

                itemsIndex = rowsCount + columnsCount;
            }
            else {
                itemsIndex = parseFloat(cell.getAttribute('fidx'));
            }

            var filters = [];
            var measuredValue = _.find(widget.metadata.panel('values').items, function (item) {
                return item.field.index === itemsIndex && !item.disabled;
            });
            var measuredValueFilters = getMeasuredValueFilters(measuredValue);

            $.merge(rowCells, colCells);
            var isGrandTotalRow;

            angular.forEach(rowCells, function (memberCell) {
                var fieldIndex;
                var items;
                isGrandTotalRow = false;

                if (memberCell.className.indexOf('p-measure-head') >= 0) {
                    fieldIndex = parseInt(memberCell.getAttribute('fDimensionIdx'));
                    items = widget.metadata.panel('columns').items;
                }
                else if (memberCell.className.indexOf('p-dim-member-head') === 0) {
                    fieldIndex = parseInt(memberCell.getAttribute('fIdx'));
                    items = widget.metadata.panel('columns').items;
                }
                else if (memberCell.className.indexOf('p-grand-total-row-head') > -1) {
                    fieldIndex = 0;
                    isGrandTotalRow = true;
                    items = widget.metadata.panel('rows').items;
                }
                else {
                    fieldIndex = parseInt(memberCell.getAttribute('fIdx'));
                    items = widget.metadata.panel('rows').items;
                }

                /*
                Do not use these methods:
                    $(memberCell)[0].innerText - adds \n to the end of the string [PSE-378]
                    $(memberCell).attr('val')  - encodes the special symbols [PSE-276]
                    $(memberCell).text() - skips datetime values
                 */

                //decodes and keeps datetime
                var textval = $("<span>").html($(memberCell).attr('val')).text();

                if (memberCell.className.indexOf('p-total-row-head')!== -1) {
                    textval = textval.replace(' Total', '');
                }

                var filter = createFilter(items, fieldIndex, textval, widget);

                // for grand total row we don't want to always add 'include all' filter for row dimension
                if (isGrandTotalRow) {
                    var widgetFilters = widget.metadata.filters();
                    var filtersWithoutDuplicates = self.getFiltersWithoutDuplicates(widgetFilters.concat(filter));
                    // widget filter with such dimension already exists
                    if (filtersWithoutDuplicates.length <= widgetFilters.length) {
                        // don't move this filter to new dashboard because current widget
                        // has a widget filter with more precise criterion which needs to be preserved.
                        return;
                    }
                }

                filters.push(filter);
            });

            return filters.concat(measuredValueFilters);
        };

        this.isPieChartWithoutCategories = function (widget) {
            if (widget.type !== 'chart/pie') {
                return false;
            }

            return !widget.metadata.panel('categories').getEnabledItems().length;
        };

        // get all filters, remove filters disabled on widget-level
        this.getFilters = function (widget, targetOrSeriesName) {
            // get widget filters object
            var widgetFilterObject = getWidgetFilters(widget, targetOrSeriesName);

            // assign widget filters object key/values to variables
            var widgetFilters = widgetFilterObject.allFilters,
                widgetFilterDims = widgetFilters.map(function (f) {
                    return f.jaql.dim;
                }),
                disabledDashboardFilters = widgetFilterObject.disabled,
                disableAllDashboardFilters = widgetFilterObject.ignoreAll; // boolean

            // set dashboard filter and merged filter defaults
            var dashboardFilters = widget.dashboard.filters.getEnabledItems(),
                filters;

            if (disableAllDashboardFilters) {
                filters = getDashboardOrWidgetFilters(widgetFilters);
            } else {
                filters = getDashboardOrWidgetFilters(widgetFilters).concat(getDashboardOrWidgetFilters(dashboardFilters));
            }

            if (disabledDashboardFilters.length > 0) {
                /* remove filters explicitly disabled on the widget-level:
                  return array of filters with dims included in widgetFilterDims or not found in disabledDashboardFilters */
                filters = _.filter(filters, function (f) {
                    if (f.isCascading) {
                        return _.any(f.levels, function (level) {
                            return _.contains(widgetFilterDims, level.dim) ? true : !_.contains(disabledDashboardFilters, level.dim);
                        });
                    } else {
                        return _.contains(widgetFilterDims, f.jaql.dim) ? true : !_.contains(disabledDashboardFilters, f.jaql.dim);
                    }
                });
            }

            return this.getFiltersWithoutDuplicates(filters);
        };

        this.getDashboardFilters = function (dashboardId) {
            var params = '?fields=filters';

            var config = {
                url: apiParams.url + '/api/' + apiParams.api + 'dashboards/' + dashboardId + params,
                type: 'GET',
            };

            return $httpCommunicateService.httpCommunicate(config, true)
                .then(function(data) {
                    return data.filters;
                });
        };

        function setInstanceIdForFilters (filters) {
            _.each(filters, function (filter) {
                if (!filter.instanceid) {
                    filter.instanceid = $$guid_fast(13);
                }
            });
        }

        function equalFilterJaqls (jaqlA, jaqlB) {
            var isSameDim = jaqlA.dim === jaqlB.dim;

            if (jaqlA.datatype === 'datetime') {
                return isSameDim && jaqlA.level === jaqlB.level;
            }

            return isSameDim;
        }

        function equalFilters (filterA, filterB) {
            if (Boolean(filterA.isCascading) !== Boolean(filterB.isCascading)) return false;

            if (filterA.isCascading) {
                if (filterA.levels.length !== filterB.levels.length) return false;

                return _.every(filterA.levels, function (level, index) {
                    return equalFilterJaqls(level, filterB.levels[index]);
                });
            }

            return equalFilterJaqls(filterA.jaql, filterB.jaql);
        }

        this.updateDashboardFilters = function (payload, dashboardId, success, error) {
            setInstanceIdForFilters(payload.filters);

            var config = {
                url: apiParams.url + '/api/' + apiParams.api + 'dashboards/' + dashboardId,
                type: 'PATCH',
                /*
                  Replace &amp; back to '&' for the filters update
                  No need to replace an apostrophe
                */
                data: angular.toJson(payload).replace(/&amp;/g, '&'),
                contentType: 'application/json;charset=UTF-8',
                success: success,
                error: error
            };

            return $httpCommunicateService.httpCommunicate(config, true);
        };

        this.isPivot = function (widgetType) {
            var pivotTypes = ['pivot', 'pivot2'];
            return pivotTypes.indexOf(widgetType) !== -1;
        }

        this.getDashboardFilterRelations = function (dashboard) {
            return dashboard && dashboard.$filterRelations;
        }

        this.setDashboardFilterRelations = function (dashboard, relations, filters) {
            dashboard.filters = filters;
            dashboard.$filterRelations = relations;
            dashboard.filterRelations = relations.toJSON();
            $dashboardNameNavigation.updateDashboard(dashboard, ['filterRelations', 'filters']);
        }
    }
]);
