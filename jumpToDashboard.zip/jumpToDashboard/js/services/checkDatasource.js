mod.service("checkDatasource", [
    function () {
        function getDatasourceUniqIdentifier(datasource) {
            if(datasource && typeof datasource === 'object') {
                return datasource.fullname || datasource.address + '/' + datasource.title;
            }

            if(typeof datasource === 'string') {
                return 'localhost/' + datasource;
            }

            return '';
        }

        this.checkDatasourceOnMatch = function(itemDatasource, widgetDatasource) {
            var itemDatasourceFullName = getDatasourceUniqIdentifier(itemDatasource);
            var widgetDatasourceFullName = getDatasourceUniqIdentifier(widgetDatasource);

            return itemDatasourceFullName.toLocaleLowerCase() === widgetDatasourceFullName.toLocaleLowerCase();
        };
    }
]);
