mod.service("dashboardUpdateAttributesService", [
    'plugin-jumpToDashboard.services.httpCommunicateService',
    function ($httpCommunicateService) {
        this.updateAttributes = function(dashboard, attributes){
            var data = _.pick(dashboard, attributes);
            var dashboardsUrl = '/api/dashboards/';
            var dashboardid = dashboard.oid;
            var putUrl = dashboardsUrl + dashboardid;

            var config = {
                method: 'PUT',
                url: putUrl,
                data: data,
                cache: false,
            };

            return $httpCommunicateService.httpCommunicate(config)
                .then(function (resp) {
                    return resp;
            });
        };
    }]);
