//Drilled Dashboard Display Class

function DrilledDashboardDisplay() {}

DrilledDashboardDisplay.prototype.url = "";
DrilledDashboardDisplay.prototype.payload = null;

//display the drilled dashboard
DrilledDashboardDisplay.prototype.display = function (filters, drillToDashboardConfig, drilledDashboard) {
    var self = this;
    var $filtersHelperService = prism.$injector.get('plugin-jumpToDashboard.services.filtersHelperService');
    var $dashboardNameNavigation = prism.$injector.get('plugin-jumpToDashboard.services.$dashboardNameNavigation');
    var featureFlags = prism.$injector.get('featureFlags');

    var drillDashboard;
    var dashboardId = $dashboardNameNavigation.getDrilledDashboardId(drilledDashboard);
    var filterRelations = $filtersHelperService.getDashboardFilterRelations(prism.activeDashboard);
    var payload = { filters: [] };

    this.payload = payload;

    return Promise.resolve()
        .then(function () {
            // get drill dashboard to set Filter Relations related options is enabled
            if (featureFlags.isOn('filterRelationsEnabled') && filterRelations) {
                return $dashboardNameNavigation.getDashboard(dashboardId);
            }

            return null;
        })
        .then(function (dashboard) {
            // save drill dashboard instance
            if (dashboard) {
                drillDashboard = dashboard;
            }
        })
        .then(function () {
            if (appConfig.drillToDashboardByName) {
                return $dashboardNameNavigation.getDashboardByName(drilledDashboard.caption);
            }
        })
        .then(function(drilledDashboardByName) {
            if (appConfig.drillToDashboardByName) {
                drilledDashboard.oidByName = $$get(drilledDashboardByName, 'oid');
            }

            dashboardId = $dashboardNameNavigation.getDrilledDashboardId(drilledDashboard);

            var excludeFilterDims = drillToDashboardConfig.excludeFilterDims;
            var includeFilterDims = drillToDashboardConfig.includeFilterDims;

            filters = $filtersHelperService.filterByExludeOrIncludeFilter(filters, excludeFilterDims, includeFilterDims);

            payload.filters = filters;

            // Adds the filters to restore to the dashboard
            if ($$get(drillToDashboardConfig, "resetDashFiltersAfterJTD")) {
                return $filtersHelperService.getDashboardFiltersToRestore(dashboardId)
                    .then(function(filtersToRestore) {
                        payload.filtersToRestore = filtersToRestore;
                        payload.openFromJTD = true;
                        return payload;
                    });
            }
            return payload;
        })
        .then(function(payload) {
            /* merge new filters with existing filters */
            if (drillToDashboardConfig.mergeTargetDashboardFilters) {
                return $filtersHelperService.mergeTargetDashFilters(filters, dashboardId)
                    .then(function(f) {
                        payload.filters = f;
                        return payload;
                    });
            }
            return payload;
        })
        .then(function (payload) {
            // set Filter Relations for drill dashboard
            if (drillDashboard) {
                $filtersHelperService.setDashboardFilterRelations(drillDashboard, filterRelations, payload.filters);
            }

            return payload;
        })
        .then(function(payload) {
            //set dashboard URL
            var $component = prism.$injector.get('$component');
            var parentEvent = $component.getParentEventTarget();
            var environment = parentEvent.getEnvironment();
            var isTokenBasedAuth = environment.isTokenBasedAuth_ instanceof Function && environment.isTokenBasedAuth_();

            // Generate JTD query string
            var dashboardOptionsStr = setParamsToUrl(drillToDashboardConfig);

            var iframeSeconds = '';

            //add seconds to URL before hash, for nested iframes. only for popup. Parameter does not affect on Angular routing
            if (drillToDashboardConfig.drilledDashboardDisplayType == 2) {
                iframeSeconds += '?q=' + Math.floor(Date.now() / 1000);
            }

            if (environment && isTokenBasedAuth) {
                var authorization = environment.getWebSessionToken();
                var initialiser = environment.getHashedWebAccessToken();
                var currentFilters = payload.filters;
                var filtersStr = "";

                if (Array.isArray(currentFilters) && currentFilters.length) {
                    filtersStr = "&filter=" + encodeURIComponent(JSON.stringify(currentFilters));
                }

                self.url = proxyUrl + "/wat/i/app/main" + iframeSeconds + "#/dashboards/" + drilledDashboard.oid + "?init=" + initialiser + "&auth=" + authorization + "&" + dashboardOptionsStr + filtersStr;
            } else {
                self.url = proxyUrl + "/app/main" + iframeSeconds + "#/dashboards/" + drilledDashboard.oid + "?" + dashboardOptionsStr;
            }

            //set payload
            self.payload = payload;
        })
        .catch(function(error) {
            throw error;
        });
};

function testParams(paramsPart) {
    if ((/true/g).test(paramsPart)) {
        return true;
    } else if((/false/g).test(paramsPart)) {
        return false;
    } else {
        return paramsPart;
    }
}

function setParamsToUrl(drillToDashboardConfig) {

    var paramsArr = [],
        splitHref = window.location.href.split('?'),
        // existing dashboard query string
        params = splitHref.length > 1 ? splitHref[splitHref.length - 1] : '',
        paramsString = '';

    // Remove filters from params string
    params = params
        .split('&')
        .filter(function (param) {
            return param.indexOf('filter=') !== 0;
        })
        .join('&');

    var paramsObject = {};

    if (params) {
        // Converting string url parameters to object format
        var paramsParts = params.split(/[\=\&]/g);

        for(var i = 0; i < paramsParts.length; i += 2) {
            paramsObject[paramsParts[i]] = testParams(paramsParts[i + 1]);
        }
    }

    // Converting config parameters to object format
    var drillObject = {
        r: drillToDashboardConfig.displayFilterPane,
        l: drillToDashboardConfig.displayDashboardsPane,
        t: drillToDashboardConfig.displayToolbarRow,
        h: drillToDashboardConfig.displayHeaderRow,
        volatile: drillToDashboardConfig.volatile
    };

    // Combining parameters from url with parameters from config
    $.extend(paramsObject, drillObject);

    // Converting full parameters to array format
    var arr = Object.keys(paramsObject).map(function (key) {
        return key + "=" + paramsObject[key];
    });

    // Converting full parameters from array to string format
    paramsString = arr.join("&");

    return paramsString;
}
