// Drilled Dashboard Display Tab class

function DrilledDashboardDisplayTab(currentTab) {
    DrilledDashboardDisplay.call(this);

    //set tab position
    if (currentTab) {
        this.self = "_self";
    }
    else {
        this.self = "_blank";
    }
}

DrilledDashboardDisplayTab.prototype = Object.create(DrilledDashboardDisplay.prototype);
DrilledDashboardDisplayTab.prototype.constructor = DrilledDashboardDisplayTab;


DrilledDashboardDisplayTab.prototype.self = "";

//display the drilled dashboard in a tab
DrilledDashboardDisplayTab.prototype.display = function (filters, drillToDashboardConfig, drilledDashboard) {
    var self = this;

    return DrilledDashboardDisplay.prototype.display.call(this, filters, drillToDashboardConfig, drilledDashboard)
        .then(function() {
            var url = self.url;
            var selfType = self.self;
            var $dashboardNameNavigation = prism.$injector.get('plugin-jumpToDashboard.services.$dashboardNameNavigation');
            var drilledDashboardId = $dashboardNameNavigation.getDrilledDashboardId(drilledDashboard);

            function success() {

                // Get parameters of the current location
                var oldParams = getParams(location.href);

                // Get parameters of the new location
                var newParams = getParams(url);

                if (selfType === "_blank") { // open dashboard in the new tab
                    window.open(url, selfType);
                } else if (oldParams === newParams){ // open dashboard in the current tab, query parameters haven't changed
                    // saves the history back-action if jumps to dashboard in current tab
                    goToDashboardPage(drilledDashboardId);
                } else { // open dashboard in the current tab, parameters are different
                    if (window.top === window.self){
                        //sisense is not embedded via iframe - just open a dashboard without anything hidden
                        goToDashboardPage(drilledDashboardId);
                    } else {
                        // embedded in the iframe
                        location.href = url;
                    }
                }
            }

            function goToDashboardPage(dashboardOid) {
                var $dashboard = prism.$injector.get('$dashboard');
                var $state = prism.$injector.get('$state');

                if (defined($dashboard, 'goToDashboardPage')) {
                    $dashboard.goToDashboardPage({ dashboardid: dashboardOid });
                } else {
                    // Fallback for old sisense versions (like v6.7)
                    var stateProps = {
                        dashboardid: dashboardOid,
                        folder: null,
                        ref: null,
                        reason: 'nav'
                    };
                    $state.go('layout.shell.dashboard', stateProps);
                }
            }

            function error(err) {
                if (err.status === 404) {
                    popNotFoundModal();
                } else {
                    throw err;
                }
            }

            var $component = prism.$injector.get('$component');
            var parentEvent = $component.getParentEventTarget();
            var environment = parentEvent.getEnvironment();
            var isTokenBasedAuth = environment.isTokenBasedAuth_ instanceof Function && environment.isTokenBasedAuth_();

            //open drilled dashboard window
            if (environment && isTokenBasedAuth) {
                success()
            } else {
                var $filtersHelperService =
                    prism.$injector.get('plugin-jumpToDashboard.services.filtersHelperService');
                return $filtersHelperService.updateDashboardFilters(self.payload, drilledDashboardId, success, error);
            }
        })


    function getParams(url) {
        var index = url.indexOf("?");
        return index > -1 ? url.substring(index + 1, url.length) : "";
    }
};
