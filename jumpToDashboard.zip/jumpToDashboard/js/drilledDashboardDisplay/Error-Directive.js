mod.directive('jtdErrorMsg', [
    function () {
        return {
            templateUrl: "/plugins/jumpToDashboard/templates/404.html",
            restrict: 'E',
        };
    }
]);

