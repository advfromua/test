// Drill To Dashboard Navigate Type Class

function DrillToDashboardNavigateType(widget) {
    //check if widget type supported
    if (this.allowedTypes.indexOf(widget.type) === -1) {
        return;
    }
    this.switchDisplayType(widget, widget.drillToDashboardConfig.drilledDashboardDisplayType);
}

DrillToDashboardNavigateType.prototype.allowedTypes = [];

//create drill to dashboard navigation
DrillToDashboardNavigateType.prototype.create = function(){};

//set drilled dashboard display mode
DrillToDashboardNavigateType.prototype.switchDisplayType = function(widget, type) {
    switch(type) {
        case 1:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayNewTab();
            break;
        case 2:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayModal();
            break;
        case 3:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayCurrentTab();
            break;
        default:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayNewTab();
            break;
    }
};