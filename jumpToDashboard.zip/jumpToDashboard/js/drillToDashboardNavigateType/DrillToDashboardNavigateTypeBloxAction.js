// Drill To Dashboard Navigate Type BloxAction Class
function DrillToDashboardNavigateTypeBloXAction(widget) {
    this.allowedTypes = ["BloX"];
    DrillToDashboardNavigateType.call(this, widget);

    //set widget events
    if (widget.$$events['ready'].handlers.indexOf(this.create) < 0) {
        widget.on('ready', this.create);
        widget.on("destroyed", removeOnReady);
    }

    // unregistering widget events
    function removeOnReady(widget, args) {
        widget.off("ready", this.create);
        widget.off("destroyed", removeOnReady);
    }
}

DrillToDashboardNavigateTypeBloXAction.prototype = Object.create(DrillToDashboardNavigateType.prototype);
DrillToDashboardNavigateTypeBloXAction.prototype.constructor = DrillToDashboardNavigateTypeBloXAction;

//create drill to dashboard navigation by Action Click
DrillToDashboardNavigateTypeBloXAction.prototype.create = function (widget, args) {
    var $filtersHelperService = prism.$injector.get('plugin-jumpToDashboard.services.filtersHelperService');
    widget.drilledDashboardDisplay.jumpFromAction = function(dashboardId, cardFilters, jtdArgs){
        var widgetFilters = $filtersHelperService.getFilters(widget);
        var drillTarget = {oid: dashboardId};
        var drillConfig = angular.extend(_.clone(widget.drillToDashboardConfig), jtdArgs);
        var filters = $filtersHelperService.mergeFilters(cardFilters , widgetFilters);

        // Changing drilled dashboard display mode on every BloX action 'click'
        if(jtdArgs.drilledDashboardDisplayType) {
            DrillToDashboardNavigateType.prototype.switchDisplayType(widget, jtdArgs.drilledDashboardDisplayType);
            widget.drilledDashboardDisplay.jumpFromAction = arguments.callee;
        }

        widget.drilledDashboardDisplay.display(filters, drillConfig, drillTarget);
    }
};
