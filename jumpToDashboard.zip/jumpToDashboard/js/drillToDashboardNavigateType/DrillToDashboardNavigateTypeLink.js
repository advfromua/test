// Drill To Dashboard Navigate Type Link Class
function DrillToDashboardNavigateTypeLink(widget) {
    this.allowedTypes = ["pivot", "pivot2"];
    DrillToDashboardNavigateType.call(this, widget);

    //set widget events
    if (widget.$$events['ready'].handlers.indexOf(this.create) < 0) {
        widget.on("ready", this.create);
        widget.on("destroyed", removeOnReady);
    }

    // unregistering widget events
    function removeOnReady(widget, args) {
        widget.off("ready", this.create);
        widget.off("destroyed", removeOnReady);
    }
}

DrillToDashboardNavigateTypeLink.prototype = Object.create(DrillToDashboardNavigateType.prototype);
DrillToDashboardNavigateTypeLink.prototype.constructor = DrillToDashboardNavigateTypeLink;

//create dashboard links with filters for each pivot cell
DrillToDashboardNavigateTypeLink.prototype.create = function (widget, args) {
    var $filtersHelperService = prism.$injector.get('plugin-jumpToDashboard.services.filtersHelperService');

    if (widget.options.drillTarget || widget.drillToDashboardConfig.dashboardIds.length) {
        setTimeout(function () {           
            if (widget.type === 'pivot2') {         
                new ReplaceValuesWithLinks(widget).replace();              
            } else {
                // get all pivot cells
                var cells = $("td.p-value", $('#' + widget.oid));
              
                // if widget filter contains "include all" filter and dashboard filter contains filter
                // for the same dimension, then dashboard filter should take precedence
                // (this may happen for grand total row cell click)
                var cleanIncludeAllWidgetFilters = function (widgetFilters, dashboardFilters) {
                    dashboardFilters.forEach(function (dashboardFilterItem) {
                        if (dashboardFilterItem.isCascading) {
                            dashboardFilterItem.levels.forEach(function (level) {
                                tryRemoveIncludeAllFilter(level.dim, widgetFilters);
                            })
                        } else {
                            tryRemoveIncludeAllFilter(dashboardFilterItem.jaql.dim, widgetFilters);
                        }
                    });
                };

                // remove widget includeAll filter of the same dimension if found
                var tryRemoveIncludeAllFilter = function (dashboardFilterItemDim, widgetFilters) {
                    // finding same widget filter but which is set to includeAll
                    var foundFilter = widgetFilters.filter(function (widgetFilterItem) {
                        return (widgetFilterItem.jaql.dim === dashboardFilterItemDim) && widgetFilterItem.jaql.filter.all;
                    })[0];

                    //remove existing widget filter
                    if (foundFilter) {
                        widgetFilters.splice(widgetFilters.indexOf(foundFilter), 1);
                    }
                };

                function getTargetDashboardOid(currentRowIndex, targetDashboards) {
                    var matchedPanelItem = _.find(widget.metadata.getEnabledItems(), function (item) {
                        return item.field.index === currentRowIndex;
                    });
                    var matchedTitle = $$get(matchedPanelItem, 'jaql.title');
                    var targetDashboard = _.find(targetDashboards, function (item) {
                        return item.pivotColumnTitle === matchedTitle;
                    });
                    var oid = $$get(targetDashboard, 'dashboardId');
                    return oid;
                }

                cells.each(function () {
                    // this === cell.
                    var pivotFilters = $filtersHelperService.getCellFilters(widget, this);                   
                    var dashboardFilters = $filtersHelperService.getFilters(widget);

                    cleanIncludeAllWidgetFilters(pivotFilters, dashboardFilters);
                    var filters = $filtersHelperService.mergeFilters(pivotFilters, dashboardFilters);
                    
                    $(this).data('filters', filters);

                    function updateFilters() {
                        var filters = $(this).data('filters');
                        var targetDashboard = widget.options.drillTarget;
                        var config = widget.drillToDashboardConfig;

                        if (config.targetDashboards && config.multipleTargetDashboardsForPivot) {
                            var currentCellFidx = parseInt($$get($(this), '0.attributes.fidx.value'));

                            var targetDashboardOid = getTargetDashboardOid(currentCellFidx, config.targetDashboards);

                            if (targetDashboardOid) {
                                targetDashboard = {
                                    oid: targetDashboardOid
                                };
                            }
                        }

                        if ($(this).attr("val") != "N\\A" || config.forceZeroInsteadNull) {
                            widget.drilledDashboardDisplay.display(filters, config, targetDashboard)
                        }
                    }

                    var clickHandlers = $$get($._data(this, "events"), 'click');

                    if (!_.find(clickHandlers, function (handler) {
                        return handler.handler == updateFilters;
                    })) {
                        $(this).on("click", updateFilters);
                    }

                    if ($(this).attr("val") != "N\\A") {
                        if ($(this).find('span').length) {
                            $(this).find('span').html('<a href="javascript:void(0);">' + $(this).find('span').html() + '</a>');
                        }
                        else {
                            $(this).find('div.p-value').html('<a href="javascript:void(0);">' + $(this).find('div.p-value').text() + '</a>');
                        }
                    }
                    else if (widget.drillToDashboardConfig.forceZeroInsteadNull) {
                        $(this).find('div').html('<a href="javascript:void(0);">' + "0" + '</a>');
                    }
                });
            }
        }, 50);

    }
};