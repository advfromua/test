function Pivot2FilterGenerator(widget) {
    var isDashboard = prism.$ngscope.appstate === 'dashboard';
    var positionRegex = 'table-grid__cell--{pos}-\\d';
    var positionTpl = '.table-grid__cell--{pos}-{val}';
    var ECellType = {
        rowGrand: 'rowsGrand',
        rowSub: 'rowsSub',
        colGrand: 'columnsGrand',
        colSub: 'columnsSub',
        common: 'common'
    };
    var cellTypeList = [{
        selector: 'table-grid__cell--row-user-type-grandTotal',
        type: ECellType.rowGrand
    },
    {
        selector: 'table-grid__cell--row-user-type-subTotal',
        type: ECellType.rowSub
    },
    {
        selector: 'table-grid__cell--col-user-type-grandTotal',
        type: ECellType.colGrand
    },
    {
        selector: 'table-grid__cell--col-user-type-subTotal',
        type: ECellType.colSub
    }];

    var selectors = {
        pivotCtr: isDashboard ? '[widgetid=' + widget.oid + ']' : '.prism-widget-preview',
        cellParent: '.table-grid__cell',
        cellValue: '.table-grid__content__inner',
        itemRow: '.table-grid__row',
        mergedRows: '.table-grid__cell--merged-rows',
        parts: {
            rows: {
                ctr: 'div.multi-grid__top-part div.table-grid--left'
            },
            rowsValue: {
                ctr: 'div.multi-grid__bottom-part',
                row: '[class*="table-grid__row-"]',
                cell: 'div.table-grid__content__inner',
            },
            values: {
                ctr: 'div.scroll-elem div.table-grid__inner-scroll',
                row: '[class*="table-grid__row-"]',
                cell: 'div.table-grid__content__inner',
            },
            columns: {
                ctr: 'div.multi-grid__top-part div.table-grid--right',
            },
        },
    }
    AbstractFiltersCreator.call(this, widget, isDashboard, positionRegex, positionTpl, selectors, cellTypeList, ECellType);
}

Pivot2FilterGenerator.prototype = Object.create(AbstractFiltersCreator.prototype);
Pivot2FilterGenerator.prototype.constructor = Pivot2FilterGenerator;

Pivot2FilterGenerator.prototype._getAffectingMember = function (affectingMembers, metadataPanelIndex) {
    var affectingMember = affectingMembers.find(function(member) {
        return member.field.index === metadataPanelIndex;
    });
    var alternateAffectingMember = affectingMembers[metadataPanelIndex];

    return affectingMember ? affectingMember : alternateAffectingMember;
};

Pivot2FilterGenerator.prototype._findRowMembersInTableRow = function (cells, params, rows, columns) {
    var self = this;
    var membersNode = [];
    for (var metadataItemIndex = params.lastRowMemberColumnIndex; metadataItemIndex >= 0; metadataItemIndex--) {
        var expectedClass = self._createMemberSelector('col', metadataItemIndex);
        var valueCell = cells.find(function (cell) {
            return cell.classList.contains(expectedClass.substr(1, expectedClass.length));
        });

        if (valueCell) {
            var filterMember = self._extractMemberValue(valueCell);
            var affectingMember = self._getAffectingMember(params.affectingMembers, params.metadataPanelIndex);

            if(affectingMember) {
                var row = rows.find(function (item) {
                    return item.index === affectingMember.field.index;
                });

                if (row) {
                    filterMember = row.member;
                }

                var column = columns.find(function (item) {
                    return item.index === affectingMember.field.index;
                });

                if (column) {
                    filterMember = column.member;
                }
            }

            membersNode.push({
                column: affectingMember ? affectingMember.jaql.column : '',
                dim: affectingMember ? affectingMember.jaql.dim : '',
                members: [filterMember]
            });

            params.metadataPanelIndex--;
            if (params.isRowPanel) {
                params.lastRowMemberColumnIndex--;
            } else {
                params.lastRowMemberColumnIndex = metadataItemIndex;
                break;
            }
        }
    }
    return membersNode;
}

Pivot2FilterGenerator.prototype._findMembers = function (candidatesWithRows, searchParameters, rows, columns) {
    var membersNode = [];
    var self = this;
    var rowIndex = 0;
    var clonedParameters = Object.assign({}, searchParameters);

    while (clonedParameters.metadataPanelIndex >= 0) {
        var cells = $(candidatesWithRows[rowIndex]).children().toArray();
        membersNode = membersNode.concat(self._findRowMembersInTableRow(cells, clonedParameters, rows, columns));
        rowIndex++
        if (rowIndex > 1000) {
            console.log('Infinite loop threat. Search stopped');
            break;
        }
    }
    return membersNode;
}

Pivot2FilterGenerator.prototype._findAffectingRowMembers = function (targetPosition, affectingMembers, panelType, rows, columns) {
    // -1 for index adjust.
    var isRowPanel = panelType === 'row';
    var metadataPanelIndex = affectingMembers.length - 1;
    var lastRowMemberColumnIndex = parseInt(targetPosition.col);
    targetPosition.row = parseInt(targetPosition.row);
    var isAddTargetRow = true;
    var valuesLength = this.findMetadataItems('values').length;
    var rowOffset = (valuesLength === 0 ? 0 : 1) + this.findMetadataItems('columns').length;
    // For rows we now index as count of Metadata elements
    if (isRowPanel) {
        if (this.isRowSub() && targetPosition.row > rowOffset) {
            isAddTargetRow = false;
        }
        if (lastRowMemberColumnIndex < affectingMembers.length) {
            metadataPanelIndex = lastRowMemberColumnIndex;
        }

        // Fix for nested columns (SNS-41322)
        if(targetPosition.col > metadataPanelIndex) {
            metadataPanelIndex = targetPosition.col;
        }
    }


    var startSliceMod = 0;
    if (!isRowPanel) {
        if (this.isColSub()) {
            this.adjustColumnSubTotalPosition(targetPosition);
        }
        if (valuesLength === 1) {
            startSliceMod = 1;
        } else {
            if (!this.isColSub()) {
                isAddTargetRow = false;
            }
        }
    }

    var startCell = this.findInitialMemberCell(targetPosition);

    var candidatesWithRows = this._selectFittingRows(startCell, startSliceMod, isAddTargetRow);

    var searchParameters = {
        lastRowMemberColumnIndex: lastRowMemberColumnIndex,
        metadataPanelIndex: metadataPanelIndex,
        affectingMembers: affectingMembers,
        isRowPanel: isRowPanel
    };
    this._handleSubTotal(searchParameters, targetPosition);
    var members = this._findMembers(candidatesWithRows, searchParameters, rows, columns);

    members.reverse();
    this._handleFirstSubTotalRow(isRowPanel, targetPosition.row, rowOffset, members);
    return members;
};

Pivot2FilterGenerator.prototype._handleFirstSubTotalRow = function(isRowPanel, rowIndex, rowOffset, members){
    if(isRowPanel && this.isRowSub() && rowIndex === rowOffset){
        var translatedTotal = prism.$injector.get("$filter")("translate")("pivot2.subTotal").trim();
        var memberValue = members[0].members[0];
        members[0].members[0] = memberValue.replace(translatedTotal, '').trim();
    }
}

Pivot2FilterGenerator.prototype._handleSubTotal = function (searchParameters, targetPosition) {
    if (searchParameters.isRowPanel && this.isRowSub()) {
        searchParameters.lastRowMemberColumnIndex = targetPosition.col;
        searchParameters.metadataPanelIndex = targetPosition.col;
        searchParameters.affectingMembers = searchParameters.affectingMembers.slice(0, targetPosition.col + 1);
    }
    else if (!searchParameters.isRowPanel && this.isColSub()) {
        var isSingleValue = this.findMetadataItems('values').length === 1;

        searchParameters.lastRowMemberColumnIndex = parseInt(targetPosition.col) - 1;
        searchParameters.metadataPanelIndex = parseInt(targetPosition.row) + (isSingleValue ? -1 : 0);
        searchParameters.affectingMembers = searchParameters.affectingMembers.slice(0, targetPosition.row + 1);
    }
}

Pivot2FilterGenerator.prototype._selectFittingRows = function (startCell, startSliceMod, isAddTargetRow) {
    startSliceMod = startSliceMod || 0;
    var closestColumnRow = $(startCell).closest(this._selectors.itemRow);

    if (closestColumnRow.length > 0) {
        var gridRowIndex = parseInt(this.extractPosIndex(closestColumnRow[0].classList[1]));

        var candidatesWithRows = closestColumnRow.siblings().toArray();
        candidatesWithRows = candidatesWithRows.slice(0 + startSliceMod, gridRowIndex);
        if (isAddTargetRow) {
            candidatesWithRows.push(closestColumnRow[0]);
        }

        return candidatesWithRows.reverse();
    }

    return [];
};

Pivot2FilterGenerator.prototype._getTargetPosition = function (target) {
    var posNames = ['col', 'row'];
    var parentCellClasses = this._getTargetParentClassList(target);
    var position = {};
    var self = this;
    posNames.forEach(function (posName) {
        var posClass = self.findPossClass(parentCellClasses, posName);
        position[posName] = self.extractPosIndex(posClass);
    });

    return position;
};

Pivot2FilterGenerator.prototype._getTargetParentClassList = function (target) {
    return $(target).closest(this._selectors.cellParent)[0].classList;
};

Pivot2FilterGenerator.prototype._adjustStartCellPosition = function (position, affectMembers, positionType) {
    var adjustPosition = Object.assign({}, position);
    if (this.isNavigateTypeLink()) {
        var affectedMember = affectMembers[affectMembers.length - 1];
        adjustPosition[positionType] = affectedMember ? affectedMember.field.index : 0;
    }
    return adjustPosition;
}

Pivot2FilterGenerator.prototype.adjustColumnSubTotalPosition = function (adjustPosition) {
    var startCell;
    // We look for Cell with 'metadata total'.
    // This cell could be not under Value column if we have multiple Values.
    // Also this finds correct index(row) of Columns metadata which was clicked.
    while (adjustPosition.col >= 0) {
        var col = this._createMemberSelector('col', adjustPosition.col);
        startCell = this.findElements(col + this._selectors.mergedRows);
        if (startCell && startCell.length > 0) break;
        adjustPosition.col--;
    }
    adjustPosition.row = this.extractPosIndex(this.findPossClass(startCell[0].classList, 'row'));
}

Pivot2FilterGenerator.prototype._modifyUniqueColumnMembers = function (column, uniqueMembers) {
    column.forEach(function(result) {
        if (!uniqueMembers[result.content]) {
            uniqueMembers[result.content] = result.value
        }
    });

    return uniqueMembers;
}

Pivot2FilterGenerator.prototype._createRowMetadataFilters = function (datasource, panelRows, panelRowsValues) {
    var jaqls = [];
    var self = this;

    if (this._isGrandTotal(panelRows)) {
        var jaql = JSON.parse(JSON.stringify(panelRows[0].jaql));
        jaql['datasource'] = datasource;
        jaql['filter'] = { all: true };
        var jaql = [{ jaql: jaql }];
        var widgetFilters = this._getFilters();
        var filtersWithoutDuplicates = this.$filtersHelperService.getFiltersWithoutDuplicates(widgetFilters.concat(jaql));
        if (widgetFilters.length >= filtersWithoutDuplicates.length) {
            return jaqls;
        }
        jaqls = jaql;
    } else {
        panelRows.forEach(function (panelItem) {
            var queryResult = $$get(panelItem, '$$panel.$$widget.queryResult', null);
            var jaql = JSON.parse(JSON.stringify(panelItem.jaql));
            var affectingMembers = panelRowsValues.find(function (rowValue) {
                return rowValue.dim === panelItem.jaql.dim;
            });
            var uniqueMembers = {};
            var newMembers;

            jaql['datasource'] = datasource;

            if (affectingMembers) {

                if (jaql.datatype === 'datetime' && !!queryResult) {
					newMembers = [];

					queryResult.columnsTreeService.columns.forEach(function(column) {
						uniqueMembers = self._modifyUniqueColumnMembers(column, uniqueMembers);
                    });

					queryResult.rowsTreeService.columns.forEach(function(column) {
						uniqueMembers = self._modifyUniqueColumnMembers(column, uniqueMembers);
                    });

					affectingMembers.members.forEach(function(member, index) {
						if (uniqueMembers[member]) {
							newMembers.push(uniqueMembers[member].substr(0, 10))
						}
                        if (affectingMembers.column === "Date" && /^\d{2}\/\d{4}$/.test(member)) {
                            // Date format "MM/yyyy" isn't recognized by Date(), so we need to change it to MM/DD/yyyy
                            var p = member.split("/");
                            affectingMembers.members[index] = p[0] + '/01/' + p[1];
                        }
					})
                }

                jaql['filter'] = {
                    members: (!!newMembers && newMembers.length) ?
                        newMembers : affectingMembers.members
                };

                jaqls.push({ jaql: jaql });
            }
        });
    }

    return jaqls;
};

Pivot2FilterGenerator.prototype._isGrandTotal = function (panelRows) {
    var grands = [this._ECellType.rowGrand, this._ECellType.colGrand];
    var result = false;
    this._cellType.forEach(function (cellType) {
        if (grands.indexOf(cellType) !== -1 && cellType.indexOf($$get(panelRows[0], 'panel', null)) !== -1) {
            result = true;
            return;
        }
    });
    return result;
}

Pivot2FilterGenerator.prototype._setCellType = function (target) {
    var cellContainerClassList = this._getTargetParentClassList(target);
    var self = this;
    this._cellTypeList.forEach(function (cellType) {
        if (cellContainerClassList.contains(cellType.selector)) {
            self._cellType.push(cellType.type)
        }
    });
    if (this._cellType.length === 0) {
        this._cellType.push(this._ECellType.common);
    }
}
