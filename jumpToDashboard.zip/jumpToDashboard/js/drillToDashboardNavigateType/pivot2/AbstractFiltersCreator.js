// Abstract class implements 'template method' pattern.
// Underscored functions treated as 'virtual' and should be implemented in child class.
function AbstractFiltersCreator(widget, isDashboard, positionRegex, positionTpl, selectors, cellTypeList, ECellType) {
    (function constructor(self, widget, isDashboard, positionRegex, positionTpl, selectors, cellTypeList, ECellType) {
        self.$filtersHelperService = prism.$injector.get('plugin-jumpToDashboard.services.filtersHelperService');
        self._widget = widget;
        self._isDashboard = isDashboard;
        self._positionRegex = positionRegex;
        self._positionTpl = positionTpl;
        self._selectors = selectors;
        self._cellTypeList = cellTypeList;
        self._cellType = [];
        self._ECellType = ECellType;
        self._rows = [];
        self._columns = [];

    })(this, widget, isDashboard, positionRegex, positionTpl, selectors, cellTypeList, ECellType)
}

AbstractFiltersCreator.prototype.createFilters = function (target, rows, columns) {
    this._rows = rows || [];
    this._columns = columns || [];
    var datasource = this._widget.datasource;
    this._setCellType(target);
    var affect = this._searchAffectingMembers(target);
    var rowFilters = this._createRowMetadataFilters(datasource, affect.panelRows.row, affect.panelRowsValues.row);
    var columnFilters = this._createRowMetadataFilters(datasource, affect.panelRows.col, affect.panelRowsValues.col);

    var targetPosition = this._getTargetPosition(target);
    var rowNumberWithFormulaTitle = (this._widget.metadata.panel('values').items.length === 1) ? 0 : columnFilters.length;
    var startCell = this.findInitialMemberCell({col: targetPosition.col, row: rowNumberWithFormulaTitle});
    var formulaTitle = $($(startCell)[0]).text();
    var clickedFormula = this._widget.metadata.panel('values').items.find(function(panel) {
        return panel.jaql.title === formulaTitle;
    });
    var measuredFilter = this.$filtersHelperService.computeMeasuredValuesFilters(clickedFormula);
    var metadataFilters = measuredFilter.concat(rowFilters).concat(columnFilters);

    var dashboardFilters = this.$filtersHelperService.getFilters(this._widget);
    this.cleanIncludeAllWidgetFilters(metadataFilters, dashboardFilters);

    var filters = this.$filtersHelperService.mergeFilters(metadataFilters, dashboardFilters);
    return filters;
};

AbstractFiltersCreator.prototype._searchAffectingMembers = function (target) {
    var panelFilters = this._findAffectingMetadata();
    var panelRowsValues = this._findAffectingMembers(target, panelFilters);
    return {
        panelRows: panelFilters,
        panelRowsValues: panelRowsValues,
    };
};

AbstractFiltersCreator.prototype._findAffectingMetadata = function () {
    return {
        row: this._findAffectingRows(),
        col: this._findAffectingColumns()
    }
};

AbstractFiltersCreator.prototype._findAffectingRows = function () {
    var metadataPanel = this.findMetadataItems('rows');

    if (this.isRowGrand()) {
        return metadataPanel.slice(0, 1);
    } else if (this.isRowSub()) {
        return metadataPanel.filter(function (panel) {
            return defined(panel.format) && defined(panel.format.subtotal);
        })
    }
    return metadataPanel;
};

AbstractFiltersCreator.prototype._findAffectingColumns = function () {
    var metadataPanel = this.findMetadataItems('columns');
    if (this.isColGrand()) {
        return metadataPanel.slice(0, 1);
    } else if (this.isColSub()) {
        return metadataPanel.filter(function (panel) {
            return defined(panel.format) && defined(panel.format.subtotal);
        })
    }
    return metadataPanel;
};

AbstractFiltersCreator.prototype.isColGrand = function () {
    return this._cellType.indexOf(this._ECellType.colGrand) !== -1;
};

AbstractFiltersCreator.prototype.isColSub = function () {
    return this._cellType.indexOf(this._ECellType.colSub) !== -1;
};

AbstractFiltersCreator.prototype.isRowGrand = function () {
    return this._cellType.indexOf(this._ECellType.rowGrand) !== -1;
};

AbstractFiltersCreator.prototype.isRowSub = function () {
    return this._cellType.indexOf(this._ECellType.rowSub) !== -1;
};

AbstractFiltersCreator.prototype._getFilters = function () {
    return this._widget.metadata.filters();
};

AbstractFiltersCreator.prototype.findMetadataItems = function (panelName) {
    var _this = this;
    return this._widget.metadata.panels
        .find(function (panel) { return panel.name === panelName; }).items
        .filter(function (item) { return !item.disabled })
        .map(function (item) {
            var jaql = item.jaql || item;

            if ((!jaql.table || !jaql.column) && jaql.dim) {
                var splitItems = _this._getTableColumnFromDim(jaql.dim);
                jaql.table = splitItems.table;
                jaql.column = splitItems.column;
            }

            return item;
        });
};

AbstractFiltersCreator.prototype._getTableColumnFromDim = function (dim) {
    var concatDim = dim.replace(/[\[\]]/g, '').replace(' (Calendar)', '');
    var splitItems = concatDim.split('.') || [];

    return {
        table: splitItems[0],
        column: splitItems[1]
    };
};

AbstractFiltersCreator.prototype._findAffectingMembers = function (target, affectingMembers) {
    var targetPosition = this._getTargetPosition(target);

    var membersRow = [];
    // Find Rows Metadata members.
    if (!this.isRowGrand()) {
        var adjustedPosition = this._adjustStartCellPosition(targetPosition, affectingMembers.row, 'col');
        membersRow = this._findAffectingRowMembers(adjustedPosition, affectingMembers.row, 'row', this._rows, this._columns);
    }

    var membersCol = [];
    // Find Column metadata members.
    if (this.isNavigateTypeLink() && !this.isColGrand()) {
        adjustedPosition = targetPosition;
        adjustedPosition.row = affectingMembers.col.length;
        membersCol = this._findAffectingRowMembers(adjustedPosition, affectingMembers.col, 'col', this._rows, this._columns);
    }

    return {
        row: membersRow,
        col: membersCol
    };
};

AbstractFiltersCreator.prototype.findElements = function (selector, table) {
    var table = table || '';
    return $(table + ' ' + selector, this._selectors.pivotCtr).toArray();
};

AbstractFiltersCreator.prototype._findMdRowTableHeader = function () {
    return findElements(this._selectors.parts.rows.ctr).find(function (row) {
        return row.children.length;
    }).map(function (cell, index) {
        return {
            index: index,
            value: cell.innerText,
        }
    })
};

AbstractFiltersCreator.prototype._findMdRowTableValues = function () {
    return this.findElements(this._selectors.parts.rowsValue.ctr);
};

AbstractFiltersCreator.prototype._createMemberSelector = function (pos, val) {
    return this._positionTpl.replace('{pos}', pos).replace('{val}', val);
};

AbstractFiltersCreator.prototype.findInitialMemberCell = function (searchStartPos) {
    var startCell;
    var row = this._createMemberSelector('row', searchStartPos.row);
    // While logic for subTotal case.
    // For Grand Total and Common cells we get strict coordinates.
    // But subTotal cell is padded left.
    while (searchStartPos.col >= 0) {
        var col = this._createMemberSelector('col', searchStartPos.col);
        startCell = this.findElements(col + row);
        if (startCell && startCell.length > 0) break;
        searchStartPos.col--;
    }
    return startCell;
};

AbstractFiltersCreator.prototype._extractMemberValue = function (memberContainers) {
    return $(this._selectors.cellValue, memberContainers).text();
};

AbstractFiltersCreator.prototype.findPossClass = function (classList, pos) {
    var colReg = new RegExp(this._positionRegex.replace('{pos}', pos));
    var posClass = '';

    classList.forEach(function (cellClass) {
        if (colReg.test(cellClass)) {
            posClass = cellClass;
        }
    });
    return posClass;
};

AbstractFiltersCreator.prototype.extractPosIndex = function (posClass) {
    var splittedName = posClass.split('-');
    return splittedName[splittedName.length - 1];
};

// If widget filter contains "include all" filter and dashboard filter contains filter.
// For the same dimension, then dashboard filter should take precedence.
// (this may happen for grand total row cell click).
AbstractFiltersCreator.prototype.cleanIncludeAllWidgetFilters = function (widgetFilters, dashboardFilters) {
    var self = this;
    dashboardFilters.forEach(function (dashboardFilterItem) {
        if (!dashboardFilterItem.isCascading) {
            self.tryRemoveIncludeAllFilter(widgetFilters, dashboardFilterItem.jaql.dim);
            return;
        }
        dashboardFilterItem.levels.forEach(function (level) {
            self.tryRemoveIncludeAllFilter(widgetFilters, level.dim);
        });
    });
};

// Remove widget includeAll filter of the same dimension if found.
AbstractFiltersCreator.prototype.tryRemoveIncludeAllFilter = function (widgetFilters, dashboardFilterItemDim) {
    // Finding same widget filter but which is set to includeAll.
    var foundFilter = widgetFilters.filter(function (widgetFilterItem) {
        return (widgetFilterItem.jaql.dim === dashboardFilterItemDim) && widgetFilterItem.jaql.filter.all;
    })[0];

    // Remove existing widget filter.
    if (foundFilter) {
        widgetFilters.splice(widgetFilters.indexOf(foundFilter), 1);
    }
};

AbstractFiltersCreator.prototype.isNavigateTypeLink = function () {
    // 1 for Right click menu. 2 - link.
    return this._widget.drillToDashboardConfig.drillToDashboardNavigateTypePivot === 2;
};
