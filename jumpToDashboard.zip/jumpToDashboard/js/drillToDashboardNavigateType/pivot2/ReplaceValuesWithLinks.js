function ReplaceValuesWithLinks(widget) {
    var isDashboard = prism.$ngscope.appstate === 'dashboard';
    this._widget = widget;
    this._selectors = {
        pivotCtr: isDashboard ? '[widgetid=' + widget.oid + ']' : '.prism-widget-preview',
        parts: {
            values: {
                ctr: 'div.scroll-elem div.table-grid__inner-scroll',
                row: '[class*="table-grid__row-"]',
                cell: 'div.table-grid__content__inner',
            },
            rowsValue: {
                ctr: 'div.multi-grid__bottom-part',
                row: '[class*="table-grid__row-"]',
                cell: 'div.table-grid__content__inner',
            },
        }
    }
}

ReplaceValuesWithLinks.prototype.replace = function (isDrillEnabled) {
    var self = this;
    var ALLOWED_EVENT_TYPE = 'click';
    var ALLOWED_CELL_TYPE = 'value';

    if (!isDrillEnabled) {
        this._widget.on('cellClick', function(widget, eventData) {
            if (
                eventData.domEvent.type === ALLOWED_EVENT_TYPE &&
                $.inArray(ALLOWED_CELL_TYPE, eventData.metadata.type) >= 0 &&
                eventData.metadata.cellData.value
            ) {
                self.handleLinkClick.call(self, eventData.domEvent, eventData.metadata.rows, eventData.metadata.columns);
            }
        });
    }
}

// Function name is essential 'function handleLinkClick'.
// It used to detect if event already bind on cell.
// Could be inproved by changing this clss on singletone and  check function by reference.
ReplaceValuesWithLinks.prototype.handleLinkClick = function handleLinkClick(e, rows, columns) {
    var drillPrm = this.prepareDrillParameters(e.target, rows, columns);
    this.openDrilledWidget(drillPrm);
};

ReplaceValuesWithLinks.prototype.prepareDrillParameters = function (target, rows, columns) {
    var filterGenerator = new Pivot2FilterGenerator(this._widget);

    var filters = filterGenerator.createFilters(target, rows, columns);
    var targetDashboard = this._widget.options.drillTarget;
    var config = this._widget.drillToDashboardConfig;
    return {
        widget: this._widget,
        filters: filters,
        config: config,
        targetDashboard: targetDashboard
    }
};

ReplaceValuesWithLinks.prototype.openDrilledWidget = function (drillPrm) {
    // Display function stored in widget object.
    // So we should get link to current widget and pass there parameters.
    this._widget.drilledDashboardDisplay.display(drillPrm.filters, drillPrm.config, drillPrm.targetDashboard);
};
