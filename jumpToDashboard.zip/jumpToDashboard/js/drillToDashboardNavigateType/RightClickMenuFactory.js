// returns method for right click menu creation depending on widget type
var RightClickMenuFactory = function () {
    var currentMember;
    var $filtersHelperService = prism.$injector.get('plugin-jumpToDashboard.services.filtersHelperService');
    var $checkRenamedDashTitles = prism.$injector.get('plugin-jumpToDashboard.services.checkRenamedDashTitles');
    var $displayAndGetDashboardsFunctions = prism.$injector.get('plugin-jumpToDashboard.services.displayAndGetDashboardsFunctions');

    // create menu item subitems if multiple target dashboards is set up
    var getMenuSubItems = function (widget, drillConfig, filters) {
        var subItems = [];
        var dashboardIds = _.clone(drillConfig.dashboardIds);
        var members = _.clone(drillConfig.members);

        // Has multiple dashboard to drill to. Set up in widget script
        if (dashboardIds && dashboardIds.length) {
            if (members && members.length) {
                var membersConfig = drillConfig.members.find(function (member) {
                    var index = member.names.indexOf(currentMember);
                    if (index !== -1) {
                        return member.names[index];
                    }
                });
            }


            if (membersConfig) {
                dashboardIds = dashboardIds.filter(function (dashboardInfo) {
                    var index = membersConfig.captions.indexOf(dashboardInfo.caption);
                    if (index !== -1) {
                        return membersConfig.captions[index];
                    }
                });
            }

            pushItemToMenu();

        }

        function pushItemToMenu() {
            dashboardIds.forEach(function (item) {

                subItems.push({
                    caption: item.caption,
                    closing: true,
                    execute: function () {
                        widget.drilledDashboardDisplay
                            .display(filters, drillConfig, { oid: item.id });
                    }
                });
            });

        }
        return subItems;

    };

    // add menu item to right click menu
    var addMenuItem = function (items, widget, filters) {
        if (!$displayAndGetDashboardsFunctions.checkIfJumpable(widget)) {
            return;
        }

        var drillConfig = widget.drillToDashboardConfig;
        var caption = drillConfig.drillToDashboardRightMenuCaption;
        var subItems = getMenuSubItems(widget, drillConfig, filters);
        var targetDashName;

        // Compute targetDashName only if dashboard has one dashboard to jumpTo
        if (!subItems.length) {
            targetDashName = $checkRenamedDashTitles.checkTargetDashName(widget);
        }
        if (!defined(widget.options, 'drillTarget.caption') && !targetDashName
            && !subItems.length && !defined(drillConfig.dashboardId)) {
            return;
        }

        if (defined(widget.options, 'drillTarget.caption')) {
            caption += targetDashName;
        }

        // If item already exists
        var menuItem = _.find(items, function (item) { return item.caption === caption; });

        if (menuItem) {
            return;
        }

        items.push({ type: 'separator' });

        menuItem = getMenuItem(widget, drillConfig, caption, subItems, filters);

        items.push(menuItem);
    };

    // create drill to dashboard navigation by right click on an custom widget
    function createCustomMenuItem(widget) {
        var createItem = function (widget) {
            var selector;

            switch (widget.type) {
                case 'imageWidget': {
                    selector = '.image-container img';
                    break;
                } case 'indicator': {
                    selector = 'indicator-number';
                    break;
                } default: {
                    break;
                }
            }

            // get clickable indicator element
            var element = getWidgetElement(widget);

            if (selector) {
                element = element.find(selector);
            }

            // Add menu item on right click.
            $(element).on('contextmenu', function (event) {
                // Remove default right click behavior.
                event.preventDefault();

                // Get menu service.
                var domService = widget.$dom;
                var items = [];

                // Pet filters.
                var filters = $filtersHelperService.getFilters(widget, element);

                addMenuItem(items, widget, filters);
                domService.menu(
                    {
                        items: items,
                        ok: function () { },
                        onClosed: function () {
                            // Added double closing for data-menu. Sometimes not closing from $dom.
                            // service
                            $('data-menu').remove();
                            $('.popup-overlay').remove();
                        }
                    },
                    {
                        target: element,
                        place: 'r',
                        anchor: 't',
                        x: event.clientX,
                        y: event.clientY,
                        css: 'drillToDashboardMenu'
                    }
                );
            });
        };

        // set widget events
        if (widget.$$events && widget.$$events.ready.handlers.indexOf(createItem) < 0) {
            widget.on('ready', createItem);
            widget.on('destroyed', removeOnReady);
        }

        // unregistering widget events
        function removeOnReady() {
            widget.off('ready', createItem);
            widget.off('destroyed', removeOnReady);
        }
    }

    function getCurentMember(args) {
        return args.settings.jaql[0].jaql.filter.members[0];
    }

    function checkIfRightClickNavigationType(args) {
        const PIVOT_RIGHT_CLICK_NAVIGATION_TYPE = 1;
        const PIVOT_NAVIGATION_TYPE = $$get(args, 'settings.widget.drillToDashboardConfig.drillToDashboardNavigateTypePivot', 0);

        return PIVOT_NAVIGATION_TYPE === PIVOT_RIGHT_CLICK_NAVIGATION_TYPE;
    }

    // create drill to dashboard navigation by right click on a pivot dimension cells
    function createPivotMenuItem(ev, args) {
        if (args.settings.name !== 'datapoint' || !checkIfRightClickNavigationType(args) ) {
            return;
        }
        currentMember = getCurentMember(args);

        var filters;

        if (args.settings.widget.type === 'pivot2') {
            var cellMetadata = args.settings.cellMetadata || {};
            var pivot2FilterGenerator = new Pivot2FilterGenerator(args.settings.widget);
            filters = pivot2FilterGenerator.createFilters(args.ui.target, cellMetadata.rows, cellMetadata.columns);
        } else {
            filters = $filtersHelperService.getFilters(args.settings.widget);
            var pivotFilters = $filtersHelperService.getCellFilters(args.settings.widget, args.ui.target);

            filters = $filtersHelperService.mergeFilters(pivotFilters, filters);
        }
        addMenuItem(args.settings.items, args.settings.widget, filters);
    }

    // create drill to dashboard navigation by right click
    function createMenuItem(ev, args) {
        if (args.settings.name !== 'datapoint') {
            return;
        }
        currentMember = getCurentMember(args);
        var widget = args.settings.widget;

        if (!$displayAndGetDashboardsFunctions.checkIfJumpable(widget)) {
            return;
        }

        var selectionFilters = args.settings.jaql || [];
        selectionFilters.forEach(function (filter) {
            if (filter.isCascading) {
                filter.levels.forEach(function (levelItem) {
                    levelItem.datasource = levelItem.datasource || widget.datasource;
                });
            } else {
                filter.jaql.datasource = filter.jaql.datasource || widget.datasource;
            }
        });

        var filters = $filtersHelperService.getFilters(args.settings.widget, args.ui.target);
        filters = $filtersHelperService.mergeFilters(selectionFilters, filters);
        addMenuItem(args.settings.items, args.settings.widget, filters);
    }

    // get menu creation function depending on widget type
    this.getMenuCreationFunction = function (widget) {
        var func;
        switch (widget.type) {
            case ('indicator'):
            case ('imageWidget'):
            case ('richtexteditor'): {
                // set widget events
                func = createCustomMenuItem;
                break;
            } case 'pivot':
            case 'pivot2': {
                func = createPivotMenuItem;
                break;
            } default: {
                func = createMenuItem;
                break;
            }
        }

        return func;
    };

    // create menu item w/w.o. subitems
    var getMenuItem = function (widget, drillConfig, caption, subItems, filters) {
        return subItems.length ?
            {
                caption: caption,
                items: subItems
            } : {
                caption: caption,
                closing: true,
                execute: function () {
                    widget.drilledDashboardDisplay
                        .display(filters, drillConfig, widget.options.drillTarget);
                }
            };
    };
};


prism.run(['basicchart.services.$highchart.selections',
    function ($highchartSelections) {
        var originalSelectionClickEvent = $highchartSelections.setPieSelectionClickEvent;

        function newPieSelectionClickEvent(widget, scope, directSelect, drillOnly) {
            return function (event) {
                var originalFunc = originalSelectionClickEvent
                    .call(this, widget, scope, directSelect, drillOnly);

                if (widget.metadata.panel('categories').getEnabledItems().length > 0) {
                    originalFunc.call(this, event);
                } else {
                    var menuFactory = new RightClickMenuFactory();
                    var rightClickMenuCreationFunction = menuFactory
                        .getMenuCreationFunction(widget);

                    if (rightClickMenuCreationFunction.name === 'createCustomMenuItem') {
                        rightClickMenuCreationFunction(widget);
                    }
                }
            };
        }
        $highchartSelections.setPieSelectionClickEvent = newPieSelectionClickEvent;
    }
]);
